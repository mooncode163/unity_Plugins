//
//  AdConfigObj.m
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//

#import "AdConfigObj.h" 
#import "Common.h"
#import "AdConfigAdmob.h"
#ifdef ENABLE_AD_GDT
#import "AdConfigGdt.h"
#endif
#ifdef ENABLE_AD_Chsj
#import "AdConfigChsj.h"
#endif
#ifdef ENABLE_AD_Baidu
#import "AdConfigBaidu.h"
#endif




//#import "AdConfigAdView.h"
#import "AdConfigUnity.h"
//#import "AdConfigInmobi.h"
//#import "AdConfigMobVista.h"

@interface AdConfigObj () //<AdBannerDelegate>


{
    //果盟横幅(Banner)广告
   // AdMoGoView  *adMogoView;
    
   //  DianJinBanner *offerBanner;
    
    //admob
    
    
    //std::string strAdSource;
}

@end

@implementation AdConfigObj
@synthesize strAdSource;
@synthesize strAppId;
@synthesize strAdKey;

static AdConfigObj *s_sharedAdConfigObj = nil;


// Init
+ (AdConfigObj *) sharedAdConfigObj
{
    @synchronized(self)     {
        if (!s_sharedAdConfigObj)
            s_sharedAdConfigObj = [[AdConfigObj alloc] init];
      //  [sharedAdBannerObj setAdSource:AD_SOURCE_ADSMOGO];
        
    }
    return s_sharedAdConfigObj;
}
 
 -(void) SetAppIdKey:(AdConfigBase *)ad type:(int)ty appid:(NSString *)appId appkey:(NSString *)appKey
{
     ad.appId = appId;
      if(ty==SOURCE_TYPE_BANNER){
            ad.appKeyBanner = appKey;
        }
        if(ty==SOURCE_TYPE_INSERT){
            ad.appKeyInsert = appKey;
        }
        if(ty==SOURCE_TYPE_SPLASH){
            ad.appKeySplash = appKey;
        }
        if(ty==SOURCE_TYPE_VIDEO){
            ad.appKeyVideo = appKey;
        }
        if(ty==SOURCE_TYPE_NATIVE){
            ad.appKeyNative = appKey;
        }
        if(ty==SOURCE_TYPE_INSERT_VIDEO){
            ad.appKeyInsertVideo = appKey;
        }
        
}
-(void) InitSDK
{
    AdConfigAdmob *ad = [AdConfigAdmob sharedAdConfigAdmob]; 
    [ad initSDK];
}

-(void) InitPlatform:(NSString *)source type:(int)ty appid:(NSString *)appId appkey:(NSString *)appKey  ad:(NSString *)adKey
{
    AdConfigBase *ad = NULL;
    if([source isEqualToString:STRING_AD_SOURCE_ADMOB])
    { 
        ad = [AdConfigAdmob sharedAdConfigAdmob]; 
    }
    
    #ifdef ENABLE_AD_GDT
    if([source isEqualToString:STRING_AD_SOURCE_GDT])
    {
       ad = [AdConfigGdt sharedAdConfigGdt];
    }
    #endif

    #ifdef ENABLE_AD_Baidu
    if([source isEqualToString:STRING_AD_SOURCE_Baidu])
    {
       ad = [AdConfigBaidu sharedAdConfigBaidu];
    }
    #endif

    #ifdef ENABLE_AD_Chsj
    if([source isEqualToString:STRING_AD_SOURCE_Chsj])
    {
       ad = [AdConfigChsj sharedAdConfig];
    }
    #endif

    // if([source isEqualToString:STRING_AD_SOURCE_ADVIEW])
    // {
    //     ad = [AdConfigAdView sharedAdConfigAdView]; 
    // }
    
    if([source isEqualToString:STRING_AD_SOURCE_UNITY])
    {
        ad = [AdConfigUnity sharedAdConfigUnity]; 
    }
    // if([source isEqualToString:STRING_AD_SOURCE_Inmobi])
    // {
    //      AdConfigInmobi *adInmobi = [AdConfigInmobi sharedAdConfigInmobi];
    //     [adInmobi initWithAccountID:appId];
    //     ad = adInmobi;
    // }
    
    // if([source isEqualToString:SOURCE_MobVista])
    // {
    //     AdConfigMobVista *adMobVista = [AdConfigMobVista sharedAdConfigMobVista];
    //     [adMobVista initSdk:appId key:appKey];
    //     ad = adMobVista;
    // }
    
    if(ad!=NULL){
        [self SetAppIdKey:ad type:ty appid:appId appkey:adKey];
    }
    
}

-(void) SetAdSource:(NSString *) source type:(int)ty
{
   self.strAdSource = source;
}
-(void) SetAppId:(NSString *) source appid:(NSString *)strid
{
    self.strAppId = strid;
}
-(void) SetAdKey:(NSString *) source type:(int)ty key:(NSString *)strkey
{
    self.strAdKey = strkey;
}

-(void) SetConfig:(NSString *) source type:(int)ty appid:(NSString *)strid key:(NSString *)strkey
{
   self.strAdSource = source;
   self.strAppId = strid;
   self.strAdKey = strkey;

}
@end
