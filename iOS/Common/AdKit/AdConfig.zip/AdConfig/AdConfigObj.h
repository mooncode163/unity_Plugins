//
//  AdBannerObj.h
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//
//#define ENABLE_AD_BAIDU

#import <Foundation/Foundation.h> 
#import "AdConfigBase.h"

@interface AdConfigObj : NSObject
{
    int screenWidth;
    int screenHeight;
}

@property(nonatomic,retain) NSString *strAdSource;
@property(nonatomic,retain) NSString *strAppId;
@property(nonatomic,retain) NSString *strAdKey;
+ (AdConfigObj *) sharedAdConfigObj;

-(void) InitPlatform:(NSString *)source type:(int)ty appid:(NSString *)appId appkey:(NSString *)appKey ad:(NSString *)adKey;
-(void) SetAdSource:(NSString *) source type:(int)ty;
-(void) SetAppId:(NSString *) source appid:(NSString *)strid;
-(void) SetAdKey:(NSString *) source type:(int)ty key:(NSString *)strkey;
-(void) SetAppIdKey:(AdConfigBase *)ad type:(int)ty appid:(NSString *)appId appkey:(NSString *)appKey;
@end
