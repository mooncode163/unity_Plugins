//
//  AdInsertBase.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import <Foundation/Foundation.h> 
#import "Common.h"

@interface AdConfigBase : NSObject
{
    
} 
@property(nonatomic,retain) NSString *appId;
@property(nonatomic,retain) NSString *appKey;
@property(nonatomic,retain) NSString *appKeyBanner;
@property(nonatomic,retain) NSString *appKeyInsert;
@property(nonatomic,retain) NSString *appKeyInsertVideo;
@property(nonatomic,retain) NSString *appKeyVideo;
@property(nonatomic,retain) NSString *appKeySplash;
@property(nonatomic,retain) NSString *appKeyNative; 
@end



