//
//  AdBanneriOS.mm
//
//  Created by Viraf Zack on 7/2/14
//  Copyright (c) 2014 Unity. All rights reserved.
//

#if __has_feature(objc_arc)
#define RETAIN self
#define AUTORELEASE self
#define RELEASE self
#define DEALLOC self
#else
#define RETAIN retain
#define AUTORELEASE autorelease
#define RELEASE release
#define DEALLOC dealloc
#endif

#import <Foundation/Foundation.h>
#import "AdConfigObj.h"
#import "AdInsertObj.h"
#include "AdConfig.h"
#import "Common.h"

#import "AdConfigAdmob.h"

 #ifdef ENABLE_AD_Chsj
#import "AdConfigChsj.h"
#endif

#if defined (__cplusplus)
extern "C"
{
#endif


     void AdConfig_SetNoAd()
    {
        Common_SetNoAd();
    }
        void AdConfig_InitSDK()
    {
        {
          AdConfigAdmob *ad = [AdConfigAdmob sharedAdConfigAdmob];
          [ad initSDK];
        }
         #ifdef ENABLE_AD_Chsj
        {
        AdConfigChsj *ad = [AdConfigChsj sharedAdConfig];
          [ad initSDK];
        }
        #endif
         
    }
    
    
    void AdConfig_InitPlatform(const char *source,int type,const char *appId,const char *appKey, char *adKey)
    {
        AdConfigObj *ad = [AdConfigObj sharedAdConfigObj];
        if((source==NULL)||(appId==NULL)||(appKey==NULL)){
            return;
        }
        [ad InitPlatform:[NSString stringWithUTF8String:source] type:type appid:[NSString stringWithUTF8String:appId] appkey:[NSString stringWithUTF8String:appKey] ad:[NSString stringWithUTF8String:adKey]];
    }
    
    void AdConfig_SetAdSource(int type,const char *source)
    {
        AdConfigObj *ad = [AdConfigObj sharedAdConfigObj];
        [ad SetAdSource:[NSString stringWithUTF8String:source] type:type];
    }
    void AdConfig_SetAppId(const char *source,const char *appid)
    {
        AdConfigObj *ad = [AdConfigObj sharedAdConfigObj];
        [ad SetAppId:[NSString stringWithUTF8String:source] appid:[NSString stringWithUTF8String:appid]];
    }

    void AdConfig_SetAdKey(const char *source,int type,const char *key)
    {
        AdConfigObj *ad = [AdConfigObj sharedAdConfigObj];
        [ad SetAdKey:[NSString stringWithUTF8String:source] type:type key:[NSString stringWithUTF8String:key]];
    }

void AdConfig_SetConfig(int type, const char * source,const char * appid,const char * adkey)
{
     AdConfigObj *ad = [AdConfigObj sharedAdConfigObj];
    switch(type){
        case SOURCE_TYPE_INSERT:
        AdInsert_DidGetAdConfig(type,source,appid,adkey);
        break;

    }
}



void AdConfig_StartGetConfig(int type)
 {
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%d",type);
    UnitySendMessage("Scene", "AdConfig_StartGetConfig", ptmp);
 }

 void AdConfig_GetAdSource(int type)
 {
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%d",type);
    UnitySendMessage("Scene", "AdConfig_GetAdSource", ptmp);
 }

void AdConfig_GetAppId(const char *source)
 {
     if(source==NULL){
         return;
     }
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%s",source);
    UnitySendMessage("Scene", "AdConfig_GetAppId", ptmp);
 }

void AdConfig_GetAdKey(const char *source,int type)
 {
     if(source==NULL){
         return;
     }
     //admob:1
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%s:%d",source,type);
    UnitySendMessage("Scene", "AdConfig_GetAdKey", ptmp);
 }


 //did get config callback
    void AdInsert_DidGetAdConfig(int type, const char * source,const char * appid,const char * adkey)
{ 
    AdInsertObj *ad = [AdInsertObj sharedAdInsertObj];
    //AdConfigObj *adConfigObj = [AdConfigObj sharedAdConfigObj];
    NSString *strSource = [NSString stringWithUTF8String:source];
    NSString *strAppId = [NSString stringWithUTF8String:appid];
    NSString *strAdKey = [NSString stringWithUTF8String:adkey];
    // [ad setAd:strSource appid:strAppId key:strAdKey];
     
}


#if defined (__cplusplus)
}
#endif

