//
//  AdBanneriOS.mm
//
//  Created by Viraf Zack on 7/2/14
//  Copyright (c) 2014 Unity. All rights reserved.
//

#if __has_feature(objc_arc)
#define RETAIN self
#define AUTORELEASE self
#define RELEASE self
#define DEALLOC self
#else
#define RETAIN retain
#define AUTORELEASE autorelease
#define RELEASE release
#define DEALLOC dealloc
#endif

#import <Foundation/Foundation.h> 
#import "AdInsertObj.h"
#include "AdConfig.h"
#import "Common.h"
 
#if defined (__cplusplus)
extern "C"
{
#endif


     void AdConfig_SetNoAd()
    {
        Common_SetNoAd();
    }
        void AdConfig_InitSDK()
    {
        
         
    }
    
    
    void AdConfig_InitPlatform(const char *source,int type,const char *appId,const char *appKey, char *adKey)
    {
       
    }
    
    void AdConfig_SetAdSource(int type,const char *source)
    {
        
    }
    void AdConfig_SetAppId(const char *source,const char *appid)
    {
        
    }

    void AdConfig_SetAdKey(const char *source,int type,const char *key)
    {
        
    }

void AdConfig_SetConfig(int type, const char * source,const char * appid,const char * adkey)
{
    
}



void AdConfig_StartGetConfig(int type)
 {
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%d",type);
    UnitySendMessage("Scene", "AdConfig_StartGetConfig", ptmp);
 }

 void AdConfig_GetAdSource(int type)
 {
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%d",type);
    UnitySendMessage("Scene", "AdConfig_GetAdSource", ptmp);
 }

void AdConfig_GetAppId(const char *source)
 {
     if(source==NULL){
         return;
     }
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%s",source);
    UnitySendMessage("Scene", "AdConfig_GetAppId", ptmp);
 }

void AdConfig_GetAdKey(const char *source,int type)
 {
     if(source==NULL){
         return;
     }
     //admob:1
    char ptmp[1024]={0}; 
    sprintf(ptmp, "%s:%d",source,type);
    UnitySendMessage("Scene", "AdConfig_GetAdKey", ptmp);
 }


 //did get config callback
    void AdInsert_DidGetAdConfig(int type, const char * source,const char * appid,const char * adkey)
{ 
    AdInsertObj *ad = [AdInsertObj sharedAdInsertObj];
    //AdConfigObj *adConfigObj = [AdConfigObj sharedAdConfigObj];
    NSString *strSource = [NSString stringWithUTF8String:source];
    NSString *strAppId = [NSString stringWithUTF8String:appid];
    NSString *strAdKey = [NSString stringWithUTF8String:adkey];
    // [ad setAd:strSource appid:strAppId key:strAdKey];
     
}


#if defined (__cplusplus)
}
#endif

