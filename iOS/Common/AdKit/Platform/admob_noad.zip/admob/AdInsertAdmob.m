//
//  AdInsertAdmob.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertAdmob.h"
#include "Common.h"
#import "AdConfigAdmob.h"

@implementation AdInsertAdmob
    
    
static AdInsertAdmob *s_sharedAdInsertAdmob = nil;
    // Init
+ (AdInsertAdmob *) sharedAdInsertAdmob
    {
        @synchronized(self)
        {
            if (!s_sharedAdInsertAdmob){
                s_sharedAdInsertAdmob = [[AdInsertAdmob alloc] init];
            }
        }
        return s_sharedAdInsertAdmob;
    }
    
-(void) loadAdTimeOut
    {
        
    }
    
-(void) show
    {
        
    }
    
-(void)showAd
    {
       
        
    }
-(void) loadAd
    {
      
    }
-(void) setAd 
    {
       
        
        
    } 
     
    @end
