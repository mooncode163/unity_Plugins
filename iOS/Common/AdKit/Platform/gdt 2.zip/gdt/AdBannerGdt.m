//
//  AdBannerGdt.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerGdt.h"
#import "AdConfigGdt.h"
#import "GDTMobBannerView.h"

@implementation AdBannerGdt

-(void) show:(bool)isShow
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    
    //return;
    viewAd.hidden = !isShow;
    //更新状态
    [self adBannerDidReceiveAd];
    
    
}
-(void)setAd
{
    AdConfigGdt *ad = [AdConfigGdt sharedAdConfigGdt];
    self.appId = ad.appId;
    self.appKey = ad.appKeyBanner;
    self.source = STRING_AD_SOURCE_GDT;
    if(isBlankString(self.appId)||([self.appId isEqualToString:@"0"])){
        [super didFail];
        return;
    }
    
    
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    // return;
    /*
    320x50	标准Banner广告	手机	GDTMOB_AD_SUGGEST_SIZE_320x50
468x60	标准Banner广告	平板电脑	GDTMOB_AD_SUGGEST_SIZE_468x60
728x90	大型Banner广告	平板电脑	GDTMOB_AD_SUGGEST_SIZE_728x90
*/

            if (!viewAd)
            { 
                     CGRect rect1 = {CGPointZero, GDTMOB_AD_SUGGEST_SIZE_320x50};
                     CGRect  rect2 = {CGPointZero, GDTMOB_AD_SUGGEST_SIZE_728x90};
                    CGRect  rect =rect1;    
                    if (IsDeviceIPad()) {
                        rect =rect2;
                    } 
 UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
  UIViewController *controller = keyWindow.rootViewController;
                bannerView = [[GDTUnifiedBannerView alloc]
                                     initWithFrame:rect
                                     placementId:self.appKey
                                     viewController:controller];
                
                    bannerView.delegate = self;
 
                // bannerView.currentViewController = controller;
                // bannerView.isAnimationOn = NO;
                // bannerView.showCloseBtn = NO;
                // bannerView.isGpsOn = YES;
                [bannerView loadAdAndShow];
    
                viewAd = [[UIView alloc]initWithFrame:CGRectMake(0, 0, bannerView.frame.size.width, bannerView.frame.size.height)];
                [viewAd addSubview:bannerView];
                //viewAd.frame = CGRectMake(0, 0, sharedAdView.frame.size.width, sharedAdView.frame.size.height);
                [controller.view addSubview:viewAd];
            }
    
}


 

#pragma mark - GDTUnifiedBannerViewDelegate
/**
 *  请求广告条数据成功后调用
 *  当接收服务器返回的广告数据成功后调用该函数
 */
- (void)unifiedBannerViewDidLoad:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"unified banner did load");
    NSLog(@"banner Received");
    [self adBannerDidReceiveAd];
}

/**
 *  请求广告条数据失败后调用
 *  当接收服务器返回的广告数据失败后调用该函数
 */

- (void)unifiedBannerViewFailedToLoad:(GDTUnifiedBannerView *)unifiedBannerView error:(NSError *)error
{
    NSLog(@"%s",__FUNCTION__);
       NSLog(@"banner failed to Received : %@",error);
    if(!viewAd){
        return;
    }
    [viewAd removeFromSuperview];
    viewAd = nil;
    
    [super didFail];
}

/**
 *  banner2.0曝光回调
 */
- (void)unifiedBannerViewWillExpose:(nonnull GDTUnifiedBannerView *)unifiedBannerView {
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  banner2.0点击回调
 */
- (void)unifiedBannerViewClicked:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  应用进入后台时调用
 *  当点击应用下载或者广告调用系统程序打开，应用将被自动切换到后台
 */
- (void)unifiedBannerViewWillLeaveApplication:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  全屏广告页已经被关闭
 */
- (void)unifiedBannerViewDidDismissFullScreenModal:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  全屏广告页即将被关闭
 */
- (void)unifiedBannerViewWillDismissFullScreenModal:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  banner2.0广告点击以后即将弹出全屏广告页
 */
- (void)unifiedBannerViewWillPresentFullScreenModal:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  banner2.0广告点击以后弹出全屏广告页完毕
 */
- (void)unifiedBannerViewDidPresentFullScreenModal:(GDTUnifiedBannerView *)unifiedBannerView
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  banner2.0被用户关闭时调用
 */
- (void)unifiedBannerViewWillClose:(nonnull GDTUnifiedBannerView *)unifiedBannerView {
    //self.bannerView = nil;
    NSLog(@"%s",__FUNCTION__);
}

 


@end
