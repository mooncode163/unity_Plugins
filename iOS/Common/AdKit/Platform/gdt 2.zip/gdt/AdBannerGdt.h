//
//  AdBannerGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerBase.h"

//gdt
//#import "GDTMobBannerView.h"
#import "GDTUnifiedBannerView.h"

@interface AdBannerGdt : AdBannerBase  <GDTUnifiedBannerViewDelegate>
{
    GDTUnifiedBannerView *bannerView;
}

-(void) show:(bool)isShow;
-(void) setAd;
@end
