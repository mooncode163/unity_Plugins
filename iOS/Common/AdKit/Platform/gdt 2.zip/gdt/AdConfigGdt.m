//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdConfigGdt.h"

@implementation AdConfigGdt 
static AdConfigGdt *s_sharedAdConfigGdt = nil;
// Init
+ (AdConfigGdt *) sharedAdConfigGdt
{
    @synchronized(self)
    {
        if (!s_sharedAdConfigGdt){
            s_sharedAdConfigGdt = [[AdConfigGdt alloc] init];
        }
    }
    return s_sharedAdConfigGdt;
}

@end
