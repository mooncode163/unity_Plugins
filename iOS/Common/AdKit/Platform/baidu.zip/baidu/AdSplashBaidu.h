//
//  AdSplashBaidu.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashBase.h"
 
@interface AdSplashBaidu : AdSplashBase 
{
     
}
-(void) show;
-(void) setAd;

@end
