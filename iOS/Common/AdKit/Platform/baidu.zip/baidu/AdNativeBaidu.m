//
//  AdConfigBaidu.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//
 
#import "AdNativeBaidu.h"
@implementation AdNativeBaidu
-(void) show  
{
    
}
-(void) setAd 
{
     self.source = STRING_AD_SOURCE_Baidu;
     
  
}

-(void) onClickAd
{
   
}
@end
