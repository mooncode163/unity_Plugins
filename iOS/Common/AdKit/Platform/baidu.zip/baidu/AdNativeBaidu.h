//
//  AdConfigBaidu.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeBase.h"

//gdt

@interface AdNativeBaidu : AdNativeBase
{ 
}
-(void) show;
-(void) setAd;
-(void) onClickAd;
@end
