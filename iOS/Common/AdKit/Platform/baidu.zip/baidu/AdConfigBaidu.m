//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdConfigBaidu.h"

@implementation AdConfigBaidu 
static AdConfigBaidu *s_sharedAdConfigBaidu = nil;
// Init
+ (AdConfigBaidu *) sharedAdConfigBaidu
{
    @synchronized(self)
    {
        if (!s_sharedAdConfigBaidu){
            s_sharedAdConfigBaidu = [[AdConfigBaidu alloc] init];
        }
    }
    return s_sharedAdConfigBaidu;
}

@end
