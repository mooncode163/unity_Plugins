//
//  AdInsertBaidu.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertBaidu.h"
#import "AdConfigBaidu.h"

#define kCustomIntWidth 300
#define kCustomIntHeight 300
#define kScreenWidth [[UIApplication sharedApplication]keyWindow].bounds.size.width
#define kScreenHeight [[UIApplication sharedApplication]keyWindow].bounds.size.height

@implementation AdInsertBaidu
static AdInsertBaidu *s_sharedAdInsertBaidu = nil;
// Init
+ (AdInsertBaidu *) sharedAdInsertBaidu
{
    @synchronized(self)
    {
        if (!s_sharedAdInsertBaidu){
            s_sharedAdInsertBaidu = [[AdInsertBaidu alloc] init];
        }
    }
    return s_sharedAdInsertBaidu;
}

-(void) show  
{
//      [self.interstitialAdView load];
      [self LoadAd];
}
-(void) setAd
{
    if(self.interstitialAdView!=nil)
       {
           return;
       }
    
     self.source = STRING_AD_SOURCE_Baidu;
    AdConfigBaidu *ad = [AdConfigBaidu sharedAdConfigBaidu];
    self.appId = ad.appId;
    self.appKey = ad.appKeyInsert;
    //self.appKey = @"4090222422425394";
    NSLog(@"baidu insert:%@,%@",self.appId,self.appKey);


     self.interstitialAdView = [[BaiduMobAdInterstitial alloc]init];
    self.interstitialAdView.AdUnitTag =self.appKey;
    self.interstitialAdView.delegate = self;
    
    //self.width = [self.widthTextField.text intValue] ? : kCustomIntWidth;
    //self.height = [self.heightTextField.text intValue] ? : kCustomIntHeight;
//    self.interstitialAdView.interstitialType = BaiduMobAdViewTypeInterstitialOther;
//BaiduMobAdViewTypeInterstitialBeforeVideo
//    BaiduMobAdViewTypeInterstitialPauseVideo
    self.interstitialAdView.interstitialType = BaiduMobAdViewTypeInterstitialOther  ;
    
    self.width =kCustomIntWidth;
    self.height =kCustomIntHeight;
//     [self.interstitialAdView loadUsingSize:CGRectMake(0, 0, self.width, self.height)];
    //_curType = 1
   
//  [self.interstitialAdView load];
}
-(void) LoadAd
{
        [self.interstitialAdView loadUsingSize:CGRectMake(0, 0, self.width, self.height)];
}
-(void) showAD
{
    //bug:不能立马显示，需要延时一会
    [self performSelector:@selector(showADDelay) withObject:nil afterDelay:1.0];
}
-(void) showADDelay
{
    [self performSelectorOnMainThread:@selector(showADInernal) withObject:nil waitUntilDone:NO];
}
-(void) showADInernal
{
    
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        UIViewController *controller = keyWindow.rootViewController;
  
      if (self.interstitialAdView.isReady) { 
//            [self.interstitialAdView presentFromRootViewController:controller];
         CGFloat origin_x = (kScreenWidth-self.width)/2;
                 CGFloat origin_y = (kScreenHeight-self.height)/3;
                 
                 UIView *customAdView = [[UIView alloc]initWithFrame:CGRectMake(origin_x, origin_y, self.width, self.height)];
                 customAdView.backgroundColor = [UIColor clearColor];
                 [controller.view addSubview:customAdView];
                 [self.interstitialAdView presentFromView:customAdView];
                self.customAdView = customAdView;
          [self AddBtnClose];
    } else {
//        NSLog(@"insert not ready yet");
//        [self.interstitialAdView load];
    }
}

-(void) AddBtnClose
{
      UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom]; //绘制形状
      float size = 24;
      float w_parent = self.customAdView.frame.size.width;
      float h_parent = self.customAdView.frame.size.height;
    float oft = 8;
        float x = w_parent-size-oft;
      float y = oft;
      btn.frame = CGRectMake(x, y, size, size);
      NSString *pic = @"AdmobBtnClose.png";
      [btn setBackgroundImage:[UIImage imageNamed:pic] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:pic] forState:UIControlStateHighlighted];

    [btn addTarget:self action:@selector(OnClickBtnClose:) forControlEvents:UIControlEventTouchUpInside];
    [self.customAdView addSubview:btn];
     

}
-(void)OnClose{
 if (self.customAdView!=nil) {
       [self.customAdView removeFromSuperview];
   }
    self.interstitialAdView = nil;

    [super didClose];
}
-(void)OnClickBtnClose:(id)sender{
    [self OnClose];
}
#pragma mark - Baidu
  

- (NSString *)publisherId {
    return self.appId;//@"ccb60059";
}

- (BOOL) enableLocation {
    return NO;
}

- (void)interstitialSuccessToLoadAd:(BaiduMobAdInterstitial *)interstitial {
    NSLog(@"load ready!");
     if(_isBackground){
      //  return;
    }
      [self showAD];
}

 /**
  *  广告预加载失败
  */
- (void)interstitialFailToLoadAd:(BaiduMobAdInterstitial *)interstitial {
      [super didFail];
    NSLog(@"insert didFail");
    self.interstitialAdView.delegate = nil;
    self.interstitialAdView = nil;
}

/**
 *  广告即将展示
 */
- (void)interstitialWillPresentScreen:(BaiduMobAdInterstitial *)interstitial {
    NSLog(@"insert will show");
     [super willShow];     
}

/**
 *  广告展示成功
 */
- (void)interstitialSuccessPresentScreen:(BaiduMobAdInterstitial *)interstitial {
    NSLog(@"insert succ show");
}

/**
 *  广告展示失败
 */
- (void)interstitialFailPresentScreen:(BaiduMobAdInterstitial *)interstitial withError:(BaiduMobFailReason) reason {
    NSLog(@"insert fail rea %d", reason);
}

/**
 *  广告展示被用户点击时的回调
 */
- (void)interstitialDidAdClicked:(BaiduMobAdInterstitial *)interstitial {
    NSLog(@"insert did click");
}

/**
 *  广告展示结束
 *  调用展示的时候, 如果与请求时的横竖屏方向不同的话, 不会展示广告并直接调用该方法.
 *  展示出来以后屏幕旋转, 广告会自动关闭并直接调用该方法.
 */
- (void)interstitialDidDismissScreen:(BaiduMobAdInterstitial *)interstitial{
    NSLog(@"insert succ dismiss");
    [self OnClose];
}

/**
 *  广告详情页被关闭
 */
- (void)interstitialDidDismissLandingPage:(BaiduMobAdInterstitial *)interstitial {
    NSLog(@"insert succ close lp");
}

 
 
 
@end
