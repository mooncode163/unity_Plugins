//
//  AdSplashBaidu.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashBaidu.h"
#import "AdConfigBaidu.h"
@implementation AdSplashBaidu
-(void) show
{
}
-(void) setAd
{
    self.source = STRING_AD_SOURCE_Baidu;
    
}


-(void) splashAdFailOnMainThread
{
 

    
}

 
@end
