//
//  AdBannerBaidu.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerBaidu.h"
#import "AdConfigBaidu.h"
#import "BaiduMobAdSDK/BaiduMobAdView.h"
#import "BaiduMobAdSDK/BaiduMobAdSetting.h"
// #import "XScreenConfig.h"
#import "BaiduMobAdSDK/BaiduMobAdDelegateProtocol.h"

@interface AdBannerBaidu() <BaiduMobAdViewDelegate>
 
@property (nonatomic, strong) NSMutableArray *bannerViewArray;
@property (nonatomic, strong) BaiduMobAdView *bannerView;

@end

@implementation AdBannerBaidu

-(void) show:(bool)isShow
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    
    //return;
    viewAd.hidden = !isShow;
    //更新状态
    [self adBannerDidReceiveAd];
    
    
}
-(void)setAd
{
    AdConfigBaidu *ad = [AdConfigBaidu sharedAdConfigBaidu];
    self.appId = ad.appId;
    self.appKey = ad.appKeyBanner;
    self.source = STRING_AD_SOURCE_Baidu;
    if(isBlankString(self.appId)||([self.appId isEqualToString:@"0"])){
        [super didFail];
        return;
    }
     
    [self addBannerWithAdId:self.appKey];
  
}


 

#pragma mark - BaiduDelegate
  
 
 

- (void)addBannerWithAdId:(NSString *)adId{
    if(self.bannerView!=nil)
    {
        return;
    }
   float  kScreenWidth = [[UIApplication sharedApplication]keyWindow].bounds.size.width;
  float  kScreenHeight = [[UIApplication sharedApplication]keyWindow].bounds.size.height;
///TODO: ATS默认开启状态, 可根据需要关闭App Transport Security Settings，设置关闭BaiduMobAdSetting的supportHttps，以请求http广告，多个产品只需要设置一次.    [BaiduMobAdSetting sharedInstance].supportHttps = NO;
   UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    //load横幅
    [self.bannerView removeFromSuperview];
    self.bannerView = [[BaiduMobAdView alloc] init];
    self.bannerView.AdType = BaiduMobAdViewTypeBanner;
    self.bannerView.delegate = self;
    // [controller.view addSubview:self.bannerView];
 
            self.bannerView.AdUnitTag =adId;// kBannerAdUnit_20_3;
            self.bannerView.frame = CGRectMake(0, 0, kScreenWidth, kScreenWidth * 3.0/20.0);
   
            viewAd = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.bannerView.frame.size.width, self.bannerView.frame.size.height)];
                [viewAd addSubview:self.bannerView]; 
                [controller.view addSubview:viewAd];

    [self.bannerView start];
}
 

- (NSString *)publisherId {
    return self.appId;// @"ccb60059"; //@"your_own_app_id";注意，iOS和android的app请使用不同的app ID
}

- (BOOL)enableLocation {
    //启用location会有一次alert提示
    return YES;
}

- (void)willDisplayAd:(BaiduMobAdView *)adview {
   // [self.scollview addSubview:adview];
    [self adBannerDidReceiveAd];
    NSLog(@"横幅广告: will display ad");
}

- (void)failedDisplayAd:(BaiduMobFailReason)reason {
   // [[[UIAlertView alloc]initWithTitle:@"该广告位暂无广告返回" message:nil delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil] show];
    [self.bannerView removeFromSuperview];
      if(!viewAd){
        return;
    }
    [viewAd removeFromSuperview];
    viewAd = nil;
    
    [super didFail];
    NSLog(@"横幅广告: failedDisplayAd %d", reason);
}

- (void)didAdImpressed {
    NSLog(@"横幅广告: didAdImpressed");
}

- (void)didAdClicked {
    NSLog(@"横幅广告: didAdClicked");
}

//点击关闭的时候移除广告
- (void)didAdClose {
//    [sharedAdView removeFromSuperview];
    NSLog(@"横幅广告: didAdClose");
}
//人群属性接口
/**
 *  - 关键词数组
 */
- (NSArray*)keywords {
    NSArray* keywords = [NSArray arrayWithObjects:@"测试",@"关键词", nil];
    return keywords;
}

/**
 *  - 用户性别
 */
- (BaiduMobAdUserGender) userGender {
    return BaiduMobAdMale; 
}

/**
 *  - 用户生日
 */
- (NSDate*) userBirthday {
    NSDate* birthday = [NSDate dateWithTimeIntervalSince1970:0];
    return birthday;
}

/**
 *  - 用户城市
 */
- (NSString*)userCity {
    return @"上海";
}


/**
 *  - 用户邮编
 */
- (NSString*)userPostalCode {
    return @"435200";
}


/**
 *  - 用户职业
 */
- (NSString*)userWork {
    return @"程序员";
}

/**
 *  - 用户最高教育学历
 *  - 学历输入数字，范围为0-6
 *  - 0表示小学，1表示初中，2表示中专/高中，3表示专科
 *  - 4表示本科，5表示硕士，6表示博士
 */
- (NSInteger)userEducation {
    return  5;
}

/**
 *  - 用户收入
 *  - 收入输入数字,以元为单位
 */
- (NSInteger)userSalary {
    return 10000;
}

/**
 *  - 用户爱好
 */
- (NSArray*)userHobbies {
    NSArray* hobbies = [NSArray arrayWithObjects:@"测试",@"爱好", nil];
    return hobbies;
}

/**
 *  - 其他自定义字段
 */
- (NSDictionary *)userOtherAttributes {
    NSMutableDictionary* other = [[NSMutableDictionary alloc] init];
    [other setValue:@"测试" forKey:@"测试"];
    return other;
}
 


@end
