//
//  AdBannerGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerBase.h"
 

@interface AdBannerBaidu : AdBannerBase  
{
     
}

-(void) show:(bool)isShow;
-(void) setAd;
@end
