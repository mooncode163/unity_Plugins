//
//  AdInsertBaidu.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertBase.h"
 
#import "BaiduMobAdSDK/BaiduMobAdInterstitial.h"
 

@interface AdInsertBaidu : AdInsertBase <BaiduMobAdInterstitialDelegate>
{
}
@property (nonatomic, strong) BaiduMobAdInterstitial *interstitialAdView;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, strong) UIView *customAdView;

+ (AdInsertBaidu *) sharedAdInsertBaidu;
-(void) show;
-(void) setAd;
-(void) showAD;
-(void) showADInernal;
-(void) showADDelay;

@end
