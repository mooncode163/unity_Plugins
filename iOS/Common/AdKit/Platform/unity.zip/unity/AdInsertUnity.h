//
//  AdVideoGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertBase.h"

#import <UnityAds/UnityAds.h>

@interface AdInsertUnity : AdInsertBase <UnityAdsDelegate>
{
    
   }

@property (copy, nonatomic) NSString* interstitialPlacementId;//普通视频插屏
@property (copy, nonatomic) NSString* incentivizedPlacementId;//激励视频
+ (AdInsertUnity *) sharedAdInsertUnity;
-(void) show;
-(void) setAd ;
-(void) onClickAd;
@end
