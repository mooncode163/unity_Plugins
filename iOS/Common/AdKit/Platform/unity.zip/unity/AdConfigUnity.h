//
//  AdInsertBase.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import <Foundation/Foundation.h> 
#import "Common.h"
#import "AdConfigBase.h"
@interface AdConfigUnity : AdConfigBase
{
    
}  
+(AdConfigUnity *) sharedAdConfigUnity;

@end



