//
//  AdVideoGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdVideoBase.h"

#import <UnityAds/UnityAds.h>

@interface AdVideoUnity : AdVideoBase <UnityAdsDelegate>
{
    
   }

@property (copy, nonatomic) NSString* interstitialPlacementId;//普通视频插屏
@property (copy, nonatomic) NSString* incentivizedPlacementId;//激励视频
+ (AdVideoUnity *) sharedAdVideoUnity;
-(void) show;
-(void) setAd ;
-(void) onClickAd;
@end
