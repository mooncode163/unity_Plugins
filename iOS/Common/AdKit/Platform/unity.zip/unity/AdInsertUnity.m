//
//  AdInsertUnity.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertUnity.h"
#import "AdConfigUnity.h"
static int kMediationOrdinal = 1;
static bool isHasInited = false;
@implementation AdInsertUnity

static AdInsertUnity *sharedAdInsertUnity = nil;
// Init
+ (AdInsertUnity *) sharedAdInsertUnity
{
    @synchronized(self)
    {
        if (!sharedAdInsertUnity){
            sharedAdInsertUnity = [[AdInsertUnity alloc] init];
        }
    }
    return sharedAdInsertUnity;
}

-(void) show  
{
    if (![UnityAds isReady]) {
       
    }else{ 
            [self showVideoInterstitial];
    }
}
-(void) setAd 
{
    if(isHasInited){
        return;
    }
    
     self.source = STRING_AD_SOURCE_UNITY;
    AdConfigUnity *ad = [AdConfigUnity sharedAdConfigUnity];
    self.appId = ad.appId;
    self.appKey = ad.appKeyInsert;
    //self.appKey = @"4090222422425394";
    NSLog(@"unity advideo:%@,%@",self.appId,self.appKey);
    
    NSString *gameId = self.appId;
    
    // mediation
    UADSMediationMetaData *mediationMetaData = [[UADSMediationMetaData alloc] init];
    [mediationMetaData setName:@"mediationPartner"];
    [mediationMetaData setVersion:@"v12345"];
    [mediationMetaData commit];
    
    UADSMetaData *debugMetaData = [[UADSMetaData alloc] init];
    [debugMetaData set:@"test.debugOverlayEnabled" value:@YES];
    [debugMetaData commit];
    
   
    
    [UnityAds setDebugMode:false];
    
    bool testMode = NO;
    
    [UnityAds initialize:gameId delegate:self testMode:testMode];
    
    isHasInited = true;
  
}

-(void) onClickAd
{
    /*点击发生，调用点击接口*/
    

}

#pragma mark unity
//激励视频
- (void)showVideoIncentivized {
    if ([UnityAds isReady]) {
        
        UADSPlayerMetaData *playerMetaData = [[UADSPlayerMetaData alloc] init];
        [playerMetaData setServerId:@"rikshot"];
        [playerMetaData commit];
        
        UADSMediationMetaData *mediationMetaData = [[UADSMediationMetaData alloc] init];
        [mediationMetaData setOrdinal:kMediationOrdinal++];
        [mediationMetaData commit];
        
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        UIViewController *controller = keyWindow.rootViewController;
        [UnityAds show:controller placementId:self.incentivizedPlacementId];
    }
}
//普通视频插屏
- (void)showVideoInterstitial {
    if ([UnityAds isReady]) {
        UADSPlayerMetaData *playerMetaData = [[UADSPlayerMetaData alloc] init];
        [playerMetaData setServerId:@"rikshot"];
        [playerMetaData commit];
        
        UADSMediationMetaData *mediationMetaData = [[UADSMediationMetaData alloc] init];
        [mediationMetaData setOrdinal:kMediationOrdinal++];
        [mediationMetaData commit];
        
        UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
        UIViewController *controller = keyWindow.rootViewController;
        [UnityAds show:controller placementId:self.interstitialPlacementId];
    }
}


- (void)unityAdsReady:(NSString *)placementId {
    
     NSLog(@"UADS Ready placementId:%@",placementId);
    if ([placementId isEqualToString:@"video"] || [placementId isEqualToString:@"defaultZone"] || [placementId isEqualToString:@"defaultVideoAndPictureZone"]) {
        self.interstitialPlacementId = placementId;
     
    }
    if ([placementId isEqualToString:@"rewardedVideo"] || [placementId isEqualToString:@"rewardedVideoZone"] || [placementId isEqualToString:@"incentivizedZone"]) {
        self.incentivizedPlacementId = placementId;
      
    }
}

- (void)unityAdsDidError:(UnityAdsError)error withMessage:(NSString *)message {
    NSLog(@"UnityAds ERROR: %ld - %@",(long)error, message);
    if (floor(NSFoundationVersionNumber) >= NSFoundationVersionNumber_iOS_8_0) {
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"UnityAds Error" message:[NSString stringWithFormat:@"%ld - %@",(long)error, message] preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
//        }];
//        [alert addAction:action];
       // [self presentViewController:alert animated:YES completion:nil];
    }
    
    [super didFail];
}

- (void)unityAdsDidStart:(NSString *)placementId {
    NSLog(@"UADS Start");
    [super willShow];   
}

- (void)unityAdsDidFinish:(NSString *)placementId withFinishState:(UnityAdsFinishState)state {
    NSString *stateString = @"UNKNOWN";
    switch (state) {
        case kUnityAdsFinishStateError:
            stateString = @"ERROR";
            break;
        case kUnityAdsFinishStateSkipped:
            stateString = @"SKIPPED";
            break;
        case kUnityAdsFinishStateCompleted:
            stateString = @"COMPLETED";
            break;
        default:
            break;
    }
    NSLog(@"UnityAds FINISH: %@ - %@", stateString, placementId);
    
  //  [super didFinish:stateString];
}




@end
