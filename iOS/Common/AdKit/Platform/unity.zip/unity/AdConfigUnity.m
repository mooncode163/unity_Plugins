//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdConfigUnity.h"

@implementation AdConfigUnity 
static AdConfigUnity *s_sharedAdConfigUnity = nil;
// Init
+ (AdConfigUnity *) sharedAdConfigUnity
{
    @synchronized(self)
    {
        if (!s_sharedAdConfigUnity){
            s_sharedAdConfigUnity = [[AdConfigUnity alloc] init];
        }
    }
    return s_sharedAdConfigUnity;
}

@end
