//
//  AdBannerAdmob.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerBase.h"

//admob
#import <GoogleMobileAds/GADBannerView.h>
#import <GoogleMobileAds/GADBannerViewDelegate.h>


@interface AdBannerAdmob : AdBannerBase <GADBannerViewDelegate>
{ 
    
    
}
-(void) show:(bool)isShow;
-(void) setAd;

@end
