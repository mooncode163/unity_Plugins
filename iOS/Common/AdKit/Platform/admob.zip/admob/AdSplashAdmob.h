//
//  AdSplashAdmob.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import <Foundation/Foundation.h>
#import "AdSplashBase.h"
#import "AdInsertAdmob.h"
 

@interface AdSplashAdmob : AdSplashBase <AdInsertDelegate>
{
    //admob
    AdInsertAdmob *adInsertAdmob;
    
     bool isHasShow;
}
-(id) init;
-(void) showAd;
-(void) show;
-(void) setAd;

@end
