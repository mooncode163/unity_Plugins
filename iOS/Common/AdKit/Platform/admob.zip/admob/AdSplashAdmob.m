//
//  AdSplashAdmob.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashAdmob.h"

@implementation AdSplashAdmob

- (id)init
{
    //首先调用父类的init方法
    self = [super init];
    //若成功返回指向对象的指针则进行初始化
    if(self) //即self！=nil；
    {
        isHasShow = false;
    }
    return self; //返回初始化完毕的对象
}

-(void) show
{
   // [adInsertAdmob show];
   
}


-(void) setAd
{
    self.source = STRING_AD_SOURCE_ADMOB;
    adInsertAdmob = [AdInsertAdmob sharedAdInsertAdmob];
    adInsertAdmob.delegate = self;
    adInsertAdmob.isUseAsSplash = true;
    [adInsertAdmob setAd]; 
}


#pragma mark delegate
- (void)AdInsertDidFail:(AdInsertBase *)ad
{
    if ([super delegate]) {
        [[super delegate] AdSplashDidFail:self];
    }
}

- (void)AdInsertDidLoad:(AdInsertBase *)ad
{
    if(isHasShow){
        return;
    }
    [adInsertAdmob show];
    isHasShow = true;
}
 

@end
