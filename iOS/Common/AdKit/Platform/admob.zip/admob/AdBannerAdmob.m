//
//  AdBannerAdmob.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerAdmob.h"
#import "AdConfigAdmob.h"

@implementation AdBannerAdmob


-(void) loadAdTimeOut
{
    isLoadAdTimeOut = true;
    if(isLoadAdEnd){
        return;
    }
    [self onAdFail];
}

-(void) show:(bool)isShow
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    
    //  isshowad = isShow;
    
    
    viewAd.hidden = !isShow;
    //更新状态
    [self adBannerDidReceiveAd];
    
    
}

-(void) setAd 
{
    
    AdConfigAdmob *ad = [AdConfigAdmob sharedAdConfigAdmob];
    
    self.source = STRING_AD_SOURCE_ADMOB;
    self.appId = ad.appId;
    self.appKey = ad.appKeyBanner;
    isLoadAdTimeOut = false;
    isLoadAdEnd = false;
    
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    {
        if (!viewAd)
        {
            
            
            GADAdSize size = kGADAdSizeBanner;
            //            switch (type) {
            //                case AdViewTypeNormalBanner:
            //                case AdViewTypeiPadNormalBanner:
            //                    size = kGADAdSizeBanner;
            //                    break;
            //                case AdViewTypeRectangle:
            //                case AdViewTypeiPhoneRectangle:
            //                    size = kGADAdSizeMediumRectangle;
            //                    break;
            //                case AdViewTypeMediumBanner:
            //                    size = kGADAdSizeFullBanner;
            //                    break;
            //                case AdViewTypeLargeBanner:
            //                    size = kGADAdSizeLeaderboard;
            //                    break;
            //                default:
            //                    [adMoGoCore adapter:self didGetAd:@"admob"];
            //                    [adMoGoCore adapter:self didFailAd:nil];
            //                    return;
            //                    break;
            //            }
            //
            /*
             /// iPhone and iPod Touch ad size. Typically 320x50.
             GAD_EXTERN GADAdSize const kGADAdSizeBanner;
             
             /// Taller version of kGADAdSizeBanner. Typically 320x100.
             GAD_EXTERN GADAdSize const kGADAdSizeLargeBanner;
             
             /// Medium Rectangle size for the iPad (especially in a UISplitView's left pane). Typically 300x250.
             GAD_EXTERN GADAdSize const kGADAdSizeMediumRectangle;
             
             /// Full Banner size for the iPad (especially in a UIPopoverController or in
             /// UIModalPresentationFormSheet). Typically 468x60.
             GAD_EXTERN GADAdSize const kGADAdSizeFullBanner;
             
             /// Leaderboard size for the iPad. Typically 728x90.
             GAD_EXTERN GADAdSize const kGADAdSizeLeaderboard;
             */
            
            if (IsDeviceIPad()) {
                size = kGADAdSizeLeaderboard;
            }else{
                
            }
            GADRequest *request = [GADRequest request];
            GADBannerView *viewAdmob = [[GADBannerView alloc] initWithAdSize:size];
            viewAdmob.opaque = NO;
            viewAdmob.adUnitID = self.appKey;//AD_APP_ID_ADMOB_BANNER;//strAppId;
            viewAdmob.delegate = self;
            
            
            viewAdmob.rootViewController =controller;
            
            // self.adNetworkView = view;
            /*2013*/
            //[controller.view addSubview:viewAdmob];
            viewAd = [[UIView alloc]initWithFrame:CGRectMake(0, 0, viewAdmob.frame.size.width, viewAdmob.frame.size.height)];
            [viewAd addSubview:viewAdmob];
            viewAdmob.frame = CGRectMake(0, 0, viewAdmob.frame.size.width, viewAdmob.frame.size.height);
            [controller.view addSubview:viewAd];
            //[viewAd release];
            
            [viewAdmob loadRequest:request];
            
             [self performSelector:@selector(loadAdTimeOut) withObject:nil afterDelay:LOAD_AD_TIMEOUT_SECODE_ADMOB];
            
            //[viewAdmob release];
        }
    }
    
    timeLoadAdms = [super getSystemMs];
    
}



-(void)onAdFail
{
    if(!viewAd){
        return;
    }
    [viewAd removeFromSuperview];
    viewAd = nil;
    [super didFail];
}

#pragma mark admob


- (void)adViewDidReceiveAd:(GADBannerView *)adView
{
    isLoadAdEnd = true;
    if(isLoadAdTimeOut){
        return;
    }
    timeLoadAdms = [super getSystemMs]-timeLoadAdms;
    NSLog(@"adViewDidReceiveAd,tick=%lldms",timeLoadAdms);
    [self adBannerDidReceiveAd];
}

- (void)bannerView:(nonnull GADBannerView *)bannerView
    didFailToReceiveAdWithError:(nonnull NSError *)error
 {
    isLoadAdEnd = true;
    if(isLoadAdTimeOut){
        return;
    }
    timeLoadAdms = [super getSystemMs]-timeLoadAdms;
    NSLog(@"didFailToReceiveAdWithError,tick=%lldms",timeLoadAdms);
    
   
    [self onAdFail];

//    if ([super delegate]) {
//        [[super delegate] AdBannerDidFail:self];
//    }
    
}


- (void)adViewWillPresentScreen:(GADBannerView *)adView {
    
    
}
- (void)adViewDidDismissScreen:(GADBannerView *)adView {
    
}


@end
