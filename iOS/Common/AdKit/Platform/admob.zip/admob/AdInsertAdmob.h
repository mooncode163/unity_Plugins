//
//  AdInsertAdmob.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import <Foundation/Foundation.h>
#import "AdInsertBase.h"
//admob
//#import <GoogleMobileAds/GADInterstitial.h>
//#import <GoogleMobileAds/GADInterstitialDelegate.h>

@interface AdInsertAdmob : AdInsertBase
{
  
    bool isPreLoad;//预加载
    
}

@property(nonatomic,assign) bool isUseAsSplash;

+ (AdInsertAdmob *) sharedAdInsertAdmob;
-(void) showAd;
-(void) show;
-(void) setAd;

@end
