//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
// 
#import <GoogleMobileAds/GoogleMobileAds.h>
#import "AdConfigAdmob.h"

@implementation AdConfigAdmob

static AdConfigAdmob *s_sharedAdConfigAdmob = nil;
// Init
+ (AdConfigAdmob *) sharedAdConfigAdmob
{
    @synchronized(self)
    {
        if (!s_sharedAdConfigAdmob){
            s_sharedAdConfigAdmob = [[AdConfigAdmob alloc] init];
        }
    }
    return s_sharedAdConfigAdmob;
}

-(void) initSDK
{
    // Initialize Google Mobile Ads SDK
  [[GADMobileAds sharedInstance] startWithCompletionHandler:nil];
}

@end
