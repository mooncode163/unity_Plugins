//
//  AdInsertAdmob.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertAdmob.h"
#include "Common.h"
#import "AdConfigAdmob.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AdInsertAdmob() <GADFullScreenContentDelegate>
{
   
    
}
@property(nonatomic, strong) GADInterstitialAd *interstitial;
@end
@implementation AdInsertAdmob
    
    
static AdInsertAdmob *s_sharedAdInsertAdmob = nil;
    // Init
+ (AdInsertAdmob *) sharedAdInsertAdmob
    {
        @synchronized(self)
        {
            if (!s_sharedAdInsertAdmob){
                s_sharedAdInsertAdmob = [[AdInsertAdmob alloc] init];
            }
        }
        return s_sharedAdInsertAdmob;
    }
    
-(void) loadAdTimeOut
    {
        isLoadingAd = false;
        isLoadAdTimeOut = true;
        if(isLoadAdEnd){
            return;
        }
        [self onAdFail];
    }
    
-(void) show
    {
        NSLog(@"admob insert show");
        // [self loadAd];

       UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
       UIViewController *controller = keyWindow.rootViewController;
       if (self.interstitial &&[self.interstitial canPresentFromRootViewController:controller
                                          error:nil]) {
           [self showAd];
       } else {
           isPreLoad = false;
           [self loadAd];
       }

     
    }
    
-(void)showAd
    {
        NSLog(@"admob insert showAd");
                    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
                    UIViewController *controller = keyWindow.rootViewController;
        
        if(isPreLoad){
            return;
        }
        
//        if (interstitialAdmob.isReady)
//        {

//            [interstitialAdmob presentFromRootViewController:controller];
//        }else{
//
//            if(!isLoadingAd){
//                isNeedShowAd = true;
//                isPreLoad = false;
//                [self loadAd];
//            }
//
//        }
       
        if (!controller) {
          return;
        }
        if (self.interstitial &&
            [self.interstitial
                canPresentFromRootViewController:controller
                                           error:nil]) {
            
            NSLog(@"admob insert showAd presentFromRootViewController");
          [self.interstitial presentFromRootViewController:controller];
        } else {
          NSLog(@"admob insert  Ad wasn't ready");
        }
        
        
    }

- (void)loadInterstitial {
  GADRequest *request = [GADRequest request];


  [GADInterstitialAd
       loadWithAdUnitID:self.appKey
                request:request
      completionHandler:^(GADInterstitialAd *ad, NSError *error) {
        if (error) {
          NSLog(@"admob insert  Failed to load interstitial ad with error: %@", [error localizedDescription]);
        [self onAdFail];
          return;
        }
        self.interstitial = ad;
        self.interstitial.fullScreenContentDelegate = self;
      
      [self showAd];
      }];
}

-(void) loadAd
    {
        
        isLoadAdEnd = false;
        [self loadInterstitial];
        /*
        if (interstitialAdmob) {
            interstitialAdmob.delegate = nil;
            //[interstitialAdmob release];
            interstitialAdmob = nil;
            
        }
        
        if (!interstitialAdmob) {
            //GADRequest *request = [GADRequest request];
            // Request test ads on devices you specify. Your test device ID is printed to the console when
            // an ad request is made. GADInterstitial automatically returns test ads when running on a
            // simulator.
            // request.testDevices = @[  @"2077ef9a63d2b398840261c8221a0c9a"  // Eric's iPod Touch];
            //ca-app-pub-3940256099942544/4411468910 demo
            {
                interstitialAdmob = [[GADInterstitial alloc] initWithAdUnitID:self.appKey];//strAppId
                //interstitialAdmob.adUnitID = strAppId;
                interstitialAdmob.delegate = self;
                
            }
            
            
            GADRequest *request = [GADRequest request];
            // Request test ads on devices you specify. Your test device ID is printed to the console when
            // an ad request is made.
            // request.testDevices = @[ GAD_SIMULATOR_ID, strAppId ];
            //request.testDevices = [NSArray arrayWithObjects: nil];
            //request.testDevices = @[ @"2077ef9a63d2b398840261c8221a0c9a"  // Eric's iPod Touch
            //                        ];
            [interstitialAdmob loadRequest:request];
            isLoadingAd = true;
            
            [self performSelector:@selector(loadAdTimeOut) withObject:nil afterDelay:LOAD_AD_TIMEOUT_SECODE_ADMOB];
        }
        
        
        isShowTime = !isShowTime;
        
        timeLoadAdms = [super getSystemMs];
        
        */
    }
-(void) setAd 
    {
        NSLog(@"admob insert:setAd enter");
        NSLog(@"AdInsertAdmob isUseAsSplash  = %@", self.isUseAsSplash ? @"YES" : @"NO");
        NSLog(@"AdInsertAdmob isUseAsSplash  delegate= %@", self.delegate);
        AdConfigAdmob *ad = [AdConfigAdmob sharedAdConfigAdmob];
         if([self.appId isEqualToString:ad.appId]){
            //只调用一次
//            return;
        }
        self.source = STRING_AD_SOURCE_ADMOB;
        self.appId = ad.appId;
        self.appKey = ad.appKeyInsert;
        //   测试广告
        //  self.appKey = @"ca-app-pub-3940256099942544/4411468910";

        NSLog(@"admob insert:self.appId=%@,appKey=%@",self.appId,self.appKey);
        
        isLoadAdTimeOut = false;
        isNeedShowAd = false;
        isReadyAdmob = false;
        isPreLoad = false;
//        [self loadAd];
        //admob 执行两次加载广告，解决第一次显示插屏要等待很长时间的问题
        static bool isfirst = false;
        if (!isfirst) {
//            [self loadAd];
        }
        isfirst = true;
        
        
        
    }
    
- (void)onAdFail
    {
       [super didFail];
    }
    



#pragma GADFullScreeContentDelegate implementation

- (void)adDidPresentFullScreenContent:(id)ad {
  NSLog(@"Ad did present full screen content.");
    
//    [super willShow];
//    [self showAd];
}

- (void)ad:(id)ad didFailToPresentFullScreenContentWithError:(NSError *)error {
  NSLog(@"Ad failed to present full screen content with error %@.", [error localizedDescription]);
    
    if(!isPreLoad){
        [self onAdFail];
    }
    
//    isLoadingAd = false;
//    if(isLoadAdTimeOut){
//        return;
//    }
//    isReadyAdmob = false;
//    isLoadAdEnd = true;
//
//    timeLoadAdms = [super getSystemMs]-timeLoadAdms;
//    NSLog(@"admob didFailToReceiveAdWithError,%lldms",timeLoadAdms);
//    if(!isPreLoad){
//        [self onAdFail];
//    }
//
    
}

- (void)adDidDismissFullScreenContent:(id)ad {
  NSLog(@"Ad did dismiss full screen content.");
    
    
    isShowTime = !isShowTime;
    
    
    {
        //        if (interstitialAdmob) {
        //            interstitialAdmob.delegate = nil;
        //            //[interstitialAdmob release];
        //            interstitialAdmob = nil;
        //
        //        }
    }
    
    [super didClose];
    
    
    if(!self.isUseAsSplash){
        //提前加载下一个广告
        isPreLoad = true;
        isNeedShowAd = false;
        [self loadAd];
    }
}
 
  
    @end
