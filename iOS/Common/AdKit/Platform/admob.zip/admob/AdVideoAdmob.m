//
//  AdVideoAdmob.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

@import GoogleMobileAds;
#import "AdVideoAdmob.h"
#import "AdConfigAdmob.h"
//#import <GoogleMobileAds/
//#import <GoogleMobileAds/GADInterstitialDelegate.h>


static int kMediationOrdinal = 1;
static bool isHasInited = false;

@interface AdVideoAdmob ()  <GADFullScreenContentDelegate>
@property(nonatomic, strong) GADRewardedAd *rewardedAd;
@end

@implementation AdVideoAdmob

static AdVideoAdmob *sharedAdVideoAdmob = nil;
// Init
+ (AdVideoAdmob *) sharedAdVideoAdmob
{
    @synchronized(self)
    {
        if (!sharedAdVideoAdmob){
            sharedAdVideoAdmob = [[AdVideoAdmob alloc] init];
        }
    }
    return sharedAdVideoAdmob;
}

-(void) show  
{
   
    [self showVideo];
}
-(void) setAd 
{
    if(isHasInited){
        return;
    }
     self.source = STRING_AD_SOURCE_ADMOB;
       AdConfigAdmob *ad = [AdConfigAdmob sharedAdConfigAdmob];
    self.appId = ad.appId;
    self.appKey = ad.appKeyVideo; 
    //self.appKey = @"4090222422425394";
    NSLog(@"admob advideo:%@,%@",self.appId,self.appKey);
    // Initialize Google Mobile Ads SDK
//    [GADMobileAds configureWithApplicationID:self.appId];
    // Initialize Google Mobile Ads SDK
    [[GADMobileAds sharedInstance] startWithCompletionHandler:nil];
    isHasInited = true;
  
    [self loadAd:self.appKey];
}

-(void) onClickAd
{
    /*点击发生，调用点击接口*/
    

}

#pragma mark admob


- (void)loadRewardedAd :(NSString *)key{
  GADRequest *request = [GADRequest request];
  [GADRewardedAd
       loadWithAdUnitID:key
                request:request
      completionHandler:^(GADRewardedAd *ad, NSError *error) {
        if (error) {
          NSLog(@"Rewarded ad failed to load with error: %@", [error localizedDescription]);
          return;
        }
        self.rewardedAd = ad;
        NSLog(@"Rewarded ad loaded.");
        self.rewardedAd.fullScreenContentDelegate = self;
      }];
}


- (void)loadAd:(NSString *)key{
    [self loadRewardedAd:key];
    
//    [GADRewardBasedVideoAd sharedInstance].delegate = self;
//    GADRequest *request = [GADRequest request];
//    //gameunity:ca-app-pub-9172948412628142/5204354407
//    //demo:ca-app-pub-3940256099942544/1712485313
//    [[GADRewardBasedVideoAd sharedInstance] loadRequest:request
//                                           withAdUnitID:key];
}

- (void)showVideo {
    
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    
//    if ([[GADRewardBasedVideoAd sharedInstance] isReady]) {
//
//        [[GADRewardBasedVideoAd sharedInstance] presentFromRootViewController:controller];
//    } else {
//
//    }
//
    
    if (self.rewardedAd && [self.rewardedAd canPresentFromRootViewController:controller error:nil]) {
      [self.rewardedAd presentFromRootViewController:controller
                            userDidEarnRewardHandler:^{
                              GADAdReward *reward = self.rewardedAd.adReward;

                              NSString *rewardMessage = [NSString
                                  stringWithFormat:@"Reward received with currency %@ , amount %lf",
                                                   reward.type, [reward.amount doubleValue]];
                              NSLog(@"%@", rewardMessage);
//                              // Reward the user for watching the video.
//                              [self earnCoins:[reward.amount integerValue]];
//                              self.showVideoButton.hidden = YES;
                            }];
    }
}



 
#pragma mark GADFullScreenContent implementation

/// Tells the delegate that the rewarded ad was presented.
- (void)adDidPresentFullScreenContent:(id)ad {
  NSLog(@"Rewarded ad presented.");
    [super didStart];
}

/// Tells the delegate that the rewarded ad failed to present.
- (void)ad:(id)ad didFailToPresentFullScreenContentWithError:(NSError *)error {
  NSLog(@"Rewarded ad failed to present with error: %@", [error localizedDescription]);
    
    [super didFail];
    
//  __weak ViewController *weakSelf = self;
//  UIAlertController *alert = [UIAlertController
//      alertControllerWithTitle:@"Rewarded Ad not ready"
//                       message:[NSString
//                                   stringWithFormat:@"Rewarded ad failed to present with error: %@",
//                                                    [error localizedDescription]]
//                preferredStyle:UIAlertControllerStyleAlert];
//  UIAlertAction *alertAction = [UIAlertAction actionWithTitle:@"Drat"
//                                                        style:UIAlertActionStyleCancel
//                                                      handler:^(UIAlertAction *action) {
//                                                        [weakSelf startNewGame];
//                                                      }];
//  [alert addAction:alertAction];
//  [self presentViewController:alert animated:YES completion:nil];
}

/// Tells the delegate that the rewarded ad was dismissed.
- (void)adDidDismissFullScreenContent:(id)ad {
//  [self loadRewardedAd];
//  self.showVideoButton.hidden = YES;
  NSLog(@"Rewarded ad dismissed.");
    
    [super didFinish:@"rewardBasedVideoAdDidClose"];
    
//加载下一个广告
   [self loadAd:self.appKey];
}
 
  
@end
