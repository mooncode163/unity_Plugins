//
//  AdNativeGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeBase.h"
#import <GoogleMobileAds/GoogleMobileAds.h>

@interface AdNativeAdmob : AdNativeBase
{
    bool isAdClosed;
}
-(void) show;
-(void) setAd;
-(void) onClickAd;
@end
