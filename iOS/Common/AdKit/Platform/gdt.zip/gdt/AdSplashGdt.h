//
//  AdSplashGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashBase.h"

//gdt
//#import "GDTMobInterstitial.h"
#import "GDTSplashAd.h"
#import "AdInsertGdt.h"
@interface AdSplashGdt : AdSplashBase <GDTSplashAdDelegate,AdInsertDelegate>
{
    
    GDTSplashAd *_splashGdt;
    AdInsertGdt *adInsertGdt;
}
-(void) show;
-(void) setAd;

@end
