//
//  AdInsertGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertBase.h"

//gdt
#import "GDTUnifiedInterstitialAd.h"

@interface AdInsertGdt : AdInsertBase <GDTUnifiedInterstitialAdDelegate>
{
    GDTUnifiedInterstitialAd *_interstitialGdt;
}
-(void) show;
-(void) setAd;
-(void) showAD;
-(void) showADInernal;
-(void) showADDelay;

@end
