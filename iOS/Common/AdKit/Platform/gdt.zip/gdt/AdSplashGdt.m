//
//  AdSplashGdt.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashGdt.h"
#import "AdConfigGdt.h"
@implementation AdSplashGdt
-(void) show
{
}
-(void) setAd
{
    self.source = STRING_AD_SOURCE_GDT;
    AdConfigGdt *ad = [AdConfigGdt sharedAdConfigGdt];
    self.appId = ad.appId;
    self.appKey = ad.appKeySplash ;//strAppKey;
    
    if(self.adType== SOURCE_TYPE_SPLASH_INSERT){
          [self performSelectorOnMainThread:@selector(splashAdFailOnMainThread) withObject:nil waitUntilDone:NO];
        return;
    }
    
    
    {
        //video
        _splashGdt = [[GDTSplashAd alloc] initWithPlacementId:self.appKey];
        _splashGdt.delegate = self;
        
        //        if ([[UIScreen mainScreen] bounds].size.height >= 568.0f) {
        //            _splashGdt.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"LaunchImage-568h"]];
        //        } else {
        //            _splashGdt.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"LaunchImage"]];
        //        }
        
        UIWindow *fK = [[UIApplication sharedApplication] keyWindow];
        _splashGdt.fetchDelay = 5;
        
        [_splashGdt loadAdAndShowInWindow:fK];
    }
}


-(void) splashAdFailOnMainThread
{

    adInsertGdt = [[AdInsertGdt alloc]init];
    adInsertGdt.delegate = self;
     
    [adInsertGdt setAd];
    [adInsertGdt show];

    
}


//
#pragma mark gdt splash
-(void)splashAdSuccessPresentScreen:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)splashAdFailToPresent:(GDTSplashAd *)splashAd withError:(NSError *)error
{
    NSLog(@"%s%@",__FUNCTION__,error);
//    {
//        CCAdSplashIos *p = (CCAdSplashIos*)poitAdSplash;
//        if (p) {
//            p->AdSplashDidFail(strAdSourceSplash);
//        }
//        
//    }
    [self performSelectorOnMainThread:@selector(splashAdFailOnMainThread) withObject:nil waitUntilDone:NO];
    
}

-(void)splashAdClicked:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)splashAdApplicationWillEnterBackground:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)splashAdWillClosed:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

-(void)splashAdClosed:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
    _splashGdt = nil;
}

- (void)splashAdWillPresentFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdDidPresentFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)splashAdWillDismissFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}
-(void)splashAdDidDismissFullScreenModal:(GDTSplashAd *)splashAd
{
    NSLog(@"%s",__FUNCTION__);
}


#pragma mark gdt insert delegate
- (void)AdInsertDidFail:(AdInsertBase *)ad
{
    if ([super delegate]) {
        [[super delegate] AdSplashDidFail:self];
    }
}
- (void)AdInsertDidLoad:(AdInsertBase *)ad
{
    NSLog(@"AdSplashGdt::AdInsertDidLoad");
}

@end
