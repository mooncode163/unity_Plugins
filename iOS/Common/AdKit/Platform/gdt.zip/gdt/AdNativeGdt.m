//
//  AdNativeGdt.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeGdt.h"
#import "AdConfigGdt.h"
@implementation AdNativeGdt
-(void) show  
{
    /*
     * 拉取广告,传入参数为拉取个数。
     * 发起拉取广告请求,在获得广告数据后回调delegate
     */
   // [_nativeAd loadAd:5]; //这里以一次拉取一条原生广告为例
}
-(void) setAd 
{
     self.source = STRING_AD_SOURCE_GDT;
    AdConfigGdt *ad = [AdConfigGdt sharedAdConfigGdt];
    self.appId = ad.appId;
    self.appKey = ad.appKeyNative;
    //self.appKey = @"4090222422425394";
    NSLog(@"gdt Native:%@,%@",self.appId,self.appKey);
//    _nativeAd = [[GDTNativeAd alloc] initWithAppkey:self.appId placementId:self.appKey];
    
//    _nativeAd= [[GDTNativeAd alloc] initWithAppId:self.appId  placementId:self.appKey];
//
//    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
//    UIViewController *controller = keyWindow.rootViewController;
//    _nativeAd.controller = controller;
//    _nativeAd.delegate = self;
    
  
}

-(void) onClickAd
{
    /*点击发生，调用点击接口*/
//    [_nativeAd clickAd:_currentAd];

}

#pragma mark gdt
-(void)nativeAdSuccessToLoad:(NSArray *)nativeAdDataArray
{
    NSLog(@"%s",__FUNCTION__);
    /*广告数据拉取成功，存储并展示*/
//    _data = nativeAdDataArray;
//    
//    if (_data ) {
//        /*选择展示广告*/
//        _currentAd = [_data objectAtIndex:0];
//        NSString *str = [_currentAd.properties objectForKey:GDTNativeAdDataKeyImgUrl];
//        [super didLoad:str];
//    }
//    
//    
  
}
 
-(void)nativeAdFailToLoad:(NSError *)error
{
    NSLog(@"%@",error);
    /*广告数据拉取失败*/
    _data = nil;
     [super didFail];
}

/**
 *  原生广告点击之后将要展示内嵌浏览器或应用内AppStore回调
 */
- (void)nativeAdWillPresentScreen
{
    NSLog(@"%s",__FUNCTION__);
}

/**
 *  原生广告点击之后应用进入后台时回调
 */
- (void)nativeAdApplicationWillEnterBackground
{
    NSLog(@"%s",__FUNCTION__);
}

- (void)nativeAdClosed
{
    NSLog(@"%s",__FUNCTION__);
}



@end
