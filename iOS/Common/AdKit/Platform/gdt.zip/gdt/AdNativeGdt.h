//
//  AdNativeGdt.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeBase.h"

//gdt
//#import "GDTNativeAd.h"

@interface AdNativeGdt : AdNativeBase // <GDTNativeAdDelegate>
{
  //  GDTNativeAd *_nativeAd;     //原生广告实例
    NSArray *_data;             //原生广告数据数组
//    GDTNativeAdData *_currentAd;//当前展示的原生广告数据对象
}
-(void) show;
-(void) setAd;
-(void) onClickAd;
@end
