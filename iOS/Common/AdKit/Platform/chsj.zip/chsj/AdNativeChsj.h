//
//  AdNativeChsj.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeBase.h"

//Chsj 

@interface AdNativeChsj  : AdNativeBase
{ 
}
-(void) show;
-(void) setAd;
-(void) onClickAd;
@end
