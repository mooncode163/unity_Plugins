//
//  AdInsertChsj.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertChsj.h"
#import "AdConfigChsj.h"


#import <BUAdSDK/BUNativeExpressInterstitialAd.h>
#import <BUAdSDK/BUSize.h>
@interface AdInsertChsj ()<BUNativeExpresInterstitialAdDelegate>
 
@property (nonatomic, strong) BUNativeExpressInterstitialAd *interstitialAd; 

@end

@implementation AdInsertChsj
-(void) show  
{
     [self.interstitialAd loadAdData];
}
-(void) setAd
{
     self.source = STRING_AD_SOURCE_Chsj;
    AdConfigChsj *ad = [AdConfigChsj sharedAdConfig];
    self.appId = ad.appId;
    self.appKey = ad.appKeyInsert;
    //self.appKey = @"4090222422425394";
    NSLog(@"Chsj insert:%@,%@",self.appId,self.appKey); 
 
    CGSize size =CGSizeMake(300, 300);
    CGFloat width = CGRectGetWidth([UIScreen mainScreen].bounds)-40;
    CGFloat height = width/size.width*size.height;
#warning 升级的用户请注意，初始化方法去掉了imgSize参数
    self.interstitialAd = [[BUNativeExpressInterstitialAd alloc] initWithSlotID:self.appKey adSize:CGSizeMake(width, height)];
    self.interstitialAd.delegate = self;
   
//    self.selectedView.promptStatus = BUDPromptStatusLoading;

     
}

-(void) showAD
{
    //bug:不能立马显示，需要延时一会
    [self performSelector:@selector(showADDelay) withObject:nil afterDelay:1.0];
}
-(void) showADDelay
{
    [self performSelectorOnMainThread:@selector(showADInernal) withObject:nil waitUntilDone:NO];
}
-(void) showADInernal
{
    
        [self showInterstitial];
}

#pragma mark - ChsjUnifiedInterstitialAdDelegate
   

- (void)showInterstitial {

          UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
          UIViewController *controller = keyWindow.rootViewController;
    
    if (self.interstitialAd) {
        [self.interstitialAd showAdFromRootViewController:controller];
    }
  //  self.selectedView.promptStatus = BUDPromptStatusDefault;
}

#pragma ---BUNativeExpresInterstitialAdDelegate
- (void)nativeExpresInterstitialAdDidLoad:(BUNativeExpressInterstitialAd *)interstitialAd {
    NSLog(@"%s",__func__);
//    [self showInterstitial];
}

- (void)nativeExpresInterstitialAd:(BUNativeExpressInterstitialAd *)interstitialAd didFailWithError:(NSError *)error {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoadedFail;
    NSLog(@"%s",__func__);
     [super didFail];
}

- (void)nativeExpresInterstitialAdRenderSuccess:(BUNativeExpressInterstitialAd *)interstitialAd {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoaded;
    NSLog(@"%s",__func__);
    //  [self showInterstitial];
    if(_isBackground){
        return;
    }
      [self showAD];
}

- (void)nativeExpresInterstitialAdRenderFail:(BUNativeExpressInterstitialAd *)interstitialAd error:(NSError *)error {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoadedFail;
    NSLog(@"%s",__func__);
    NSLog(@"error code : %ld , error message : %@",(long)error.code,error.description);
     [super didFail];
}

- (void)nativeExpresInterstitialAdWillVisible:(BUNativeExpressInterstitialAd *)interstitialAd {
    NSLog(@"%s",__func__);
    [super willShow];    
}

- (void)nativeExpresInterstitialAdDidClick:(BUNativeExpressInterstitialAd *)interstitialAd {
    NSLog(@"%s",__func__);
}

- (void)nativeExpresInterstitialAdWillClose:(BUNativeExpressInterstitialAd *)interstitialAd {
    NSLog(@"%s",__func__);
}

- (void)nativeExpresInterstitialAdDidClose:(BUNativeExpressInterstitialAd *)interstitialAd {
    NSLog(@"%s",__func__);
        [super didClose];
}

- (void)nativeExpresInterstitialAdDidCloseOtherController:(BUNativeExpressInterstitialAd *)interstitialAd interactionType:(BUInteractionType)interactionType {
    NSString *str = nil;
    if (interactionType == BUInteractionTypePage) {
        str = @"ladingpage";
    } else if (interactionType == BUInteractionTypeVideoAdDetail) {
        str = @"videoDetail";
    } else {
        str = @"appstoreInApp";
    }
    NSLog(@"%s __ %@",__func__,str);
}
@end
