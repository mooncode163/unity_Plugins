//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdConfigChsj.h"
#import <BUAdSDK/BUAdSDKManager.h>
@implementation AdConfigChsj 
static AdConfigChsj *s_sharedAdConfig = nil;
// Init
+ (AdConfigChsj *) sharedAdConfig
{
    @synchronized(self)
    {
        if (!s_sharedAdConfig){
            s_sharedAdConfig = [[AdConfigChsj alloc] init];
        }
    }
    return s_sharedAdConfig;
}
-(void) initSDK
{
    if(self.appId==nil){
        return;
    }
   [BUAdSDKManager setAppID:self.appId];
}
@end
