//
//  AdNativeChsj.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdNativeChsj.h"
#import "AdConfigChsj.h"
@implementation AdNativeChsj
-(void) show  
{
 
}
-(void) setAd 
{
     self.source = STRING_AD_SOURCE_Chsj;
    AdConfigChsj *ad = [AdConfigChsj sharedAdConfig];
    self.appId = ad.appId;
    self.appKey = ad.appKeyNative;
    //self.appKey = @"4090222422425394";
    NSLog(@"Chsj Native:%@,%@",self.appId,self.appKey);
 
    
  
}
 
 



@end
