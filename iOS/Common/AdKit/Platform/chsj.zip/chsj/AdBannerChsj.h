//
//  AdBannerChsj.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerBase.h"

//Chsj 

@interface AdBannerChsj : AdBannerBase  
{
    
}

-(void) show:(bool)isShow;
-(void) setAd;
@end
