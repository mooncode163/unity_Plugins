//
//  AdSplashChsj.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashBase.h"

//Chsj 
#import "AdInsertChsj.h"
@interface AdSplashChsj : AdSplashBase  
{ 
}
-(void) show;
-(void) setAd;

@end
