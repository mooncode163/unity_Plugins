//
//  AdInsertChsj.h
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdInsertBase.h"
 

@interface AdInsertChsj : AdInsertBase
{
     
}
-(void) show;
-(void) setAd;
-(void) showAD;
-(void) showADInernal;
-(void) showADDelay;

@end
