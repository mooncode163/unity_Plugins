//
//  AdSplashChsj.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdSplashChsj.h"
#import "AdConfigChsj.h"
@implementation AdSplashChsj
-(void) show
{
}
-(void) setAd
{
    self.source = STRING_AD_SOURCE_Chsj;
    AdConfigChsj *ad = [AdConfigChsj sharedAdConfig];
    self.appId = ad.appId;
    self.appKey = ad.appKeySplash ;//strAppKey;
    
    if(self.adType== SOURCE_TYPE_SPLASH_INSERT){
          [self performSelectorOnMainThread:@selector(splashAdFailOnMainThread) withObject:nil waitUntilDone:NO];
        return;
    }
    
    
    // {
    //     //video
    //     _splashChsj = [[ChsjSplashAd alloc] initWithPlacementId:self.appKey];
    //     _splashChsj.delegate = self;
        
    //     //        if ([[UIScreen mainScreen] bounds].size.height >= 568.0f) {
    //     //            _splashChsj.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"LaunchImage-568h"]];
    //     //        } else {
    //     //            _splashChsj.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"LaunchImage"]];
    //     //        }
        
    //     UIWindow *fK = [[UIApplication sharedApplication] keyWindow];
    //     _splashChsj.fetchDelay = 5;
        
    //     [_splashChsj loadAdAndShowInWindow:fK];
    // }
}


-(void) splashAdFailOnMainThread
{
 

    
}

 
#pragma mark Chsj insert delegate
- (void)AdInsertDidFail:(AdInsertBase *)ad
{
    if ([super delegate]) {
        [[super delegate] AdSplashDidFail:self];
    }
}
- (void)AdInsertDidLoad:(AdInsertBase *)ad
{
    NSLog(@"AdSplashChsj::AdInsertDidLoad");
}

@end
