//
//  AdBannerChsj.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdBannerChsj.h"
#import "AdConfigChsj.h"
#import <BUAdSDK/BUNativeExpressBannerView.h>
#import <BUAdSDK/BUAdSDK.h>

@interface AdBannerChsj ()<BUNativeExpressBannerViewDelegate>
 
@property(nonatomic, strong) BUNativeExpressBannerView *bannerView;

@end

@implementation AdBannerChsj

-(void) show:(bool)isShow
{
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    
    //return;
    viewAd.hidden = !isShow;
    //更新状态
    [self adBannerDidReceiveAd];
    
    
}
-(void)setAd
{
    AdConfigChsj *ad = [AdConfigChsj sharedAdConfig];
    self.appId = ad.appId;
    self.appKey = ad.appKeyBanner;
    self.source = STRING_AD_SOURCE_Chsj;
    if(isBlankString(self.appId)||([self.appId isEqualToString:@"0"])){
        [super didFail];
        return;
    }
    
    
    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];
    UIViewController *controller = keyWindow.rootViewController;
    // return;
    /*
    320x50	标准Banner广告	手机	ChsjMOB_AD_SUGGEST_SIZE_320x50
468x60	标准Banner广告	平板电脑	ChsjMOB_AD_SUGGEST_SIZE_468x60
728x90	大型Banner广告	平板电脑	ChsjMOB_AD_SUGGEST_SIZE_728x90
*/

            if (!viewAd)
            {   
   CGSize size = CGSizeMake(600, 90);
    CGFloat screenWidth = CGRectGetWidth([UIScreen mainScreen].bounds);
    CGFloat bannerHeigh = screenWidth/size.width*size.height;
#warning 升级的用户请注意，初始化方法去掉了imgSize参数
//    if (self.isCarouselSwitch.on) {
//        self.bannerView = [[BUNativeExpressBannerView alloc] initWithSlotID:slotID rootViewController:self adSize:CGSizeMake(screenWidth, bannerHeigh) IsSupportDeepLink:YES interval:30];
//    } else {
        self.bannerView = [[BUNativeExpressBannerView alloc] initWithSlotID:self.appKey rootViewController:controller adSize:CGSizeMake(screenWidth, bannerHeigh) IsSupportDeepLink:YES];
//    }
    //self.view.frame.size.height-bannerHeigh
    self.bannerView.frame = CGRectMake(0, 0, screenWidth, bannerHeigh);
    self.bannerView.delegate = self;
    [self.bannerView loadAdData];


                 viewAd = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.bannerView.frame.size.width, self.bannerView.frame.size.height)];
                [viewAd addSubview:self.bannerView];
                 [controller.view addSubview:viewAd];
                 

            }
    
}


 

#pragma mark - ChsjUnifiedBannerViewDelegate
 

#pragma BUNativeExpressBannerViewDelegate
- (void)nativeExpressBannerAdViewDidLoad:(BUNativeExpressBannerView *)bannerAdView {
    NSLog(@"%s",__func__);
        [self adBannerDidReceiveAd];
}

- (void)nativeExpressBannerAdView:(BUNativeExpressBannerView *)bannerAdView didLoadFailWithError:(NSError *)error {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoadedFail;
    NSLog(@"%s",__func__);
    NSLog(@"error code : %ld , error message : %@",(long)error.code,error.description);

        if(!viewAd){
        return;
    }
    [viewAd removeFromSuperview];
    viewAd = nil;
    
    [super didFail];

}

- (void)nativeExpressBannerAdViewRenderSuccess:(BUNativeExpressBannerView *)bannerAdView {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoaded;
    NSLog(@"%s",__func__);
}

- (void)nativeExpressBannerAdViewRenderFail:(BUNativeExpressBannerView *)bannerAdView error:(NSError *)error {
//    self.selectedView.promptStatus = BUDPromptStatusAdLoadedFail;
    NSLog(@"%s",__func__);
}

- (void)nativeExpressBannerAdViewWillBecomVisible:(BUNativeExpressBannerView *)bannerAdView {
    NSLog(@"%s",__func__);
}

- (void)nativeExpressBannerAdViewDidClick:(BUNativeExpressBannerView *)bannerAdView {
    NSLog(@"%s",__func__);
}

- (void)nativeExpressBannerAdView:(BUNativeExpressBannerView *)bannerAdView dislikeWithReason:(NSArray<BUDislikeWords *> *)filterwords {
    NSLog(@"%s",__func__);
    [UIView animateWithDuration:0.25 animations:^{
        bannerAdView.alpha = 0;
    } completion:^(BOOL finished) {
        [viewAd removeFromSuperview];
        viewAd = nil;
    }];
//    self.selectedView.promptStatus = BUDPromptStatusDefault;
}

- (void)nativeExpressBannerAdViewDidCloseOtherController:(BUNativeExpressBannerView *)bannerAdView interactionType:(BUInteractionType)interactionType {
    NSString *str = nil;
    if (interactionType == BUInteractionTypePage) {
        str = @"ladingpage";
    } else if (interactionType == BUInteractionTypeVideoAdDetail) {
        str = @"videoDetail";
    } else {
        str = @"appstoreInApp";
    }
    NSLog(@"%s __ %@",__func__,str);
}

@end
