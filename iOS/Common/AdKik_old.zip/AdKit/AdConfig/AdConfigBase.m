//
//  AdInsertBase.m
//  Unity-iPhone
//
//  Created by jaykie Chen on 17/4/14.
//
//

#import "AdConfigBase.h"

@implementation AdConfigBase
@synthesize appId;
@synthesize appKeyBanner;
@synthesize appKeyInsert;
@synthesize appKeyInsertVideo;
@synthesize appKeyVideo;
@synthesize appKeySplash;
@synthesize appKeyNative; 

@end
