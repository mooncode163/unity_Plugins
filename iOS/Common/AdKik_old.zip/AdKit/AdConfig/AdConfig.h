#ifndef _ADCONFIG_H
#define _ADCONFIG_H
  // 

#if defined (__cplusplus)
extern "C"
{
#endif
void AdConfig_StartGetConfig(int type);
void AdConfig_GetAdSource(int type);
void AdConfig_GetAppId(const char *source);
void AdConfig_GetAdKey(const char *source,int type);
void AdInsert_DidGetAdConfig(int type, const char * source,const char * appid,const char * adkey);

#if defined (__cplusplus)
}
#endif


#endif
