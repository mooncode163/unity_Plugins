//
//  CCAdApplistObj.h
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//

#import <Foundation/Foundation.h>


@interface ShareObj : NSObject
{
    void *pointThis;//类指针
    
}

@property(nonatomic,retain) NSString *appId;
@property(nonatomic,retain) NSString *appKey;
@property (nonatomic,retain) NSString *unityObjName;

+ (ShareObj *) sharedShareObj;
-(void) setAppKey:(NSString *)strAppKey;
-(void) ShareWeb:(NSString *)strSource title:(NSString *)strTitle detail:(NSString *)strDetail url:(NSString *)strUrl;
- (void)ShareImage:(NSString *)strSource pic:(NSString *)strPic url:(NSString *)strUrl;
- (void)ShareImageText:(NSString *)strSource title:(NSString *)strTitle pic:(NSString *)strPic url:(NSString *)strUrl;
-(void) setClassePoit:(void *) p ;
- (void)initPlatform:(NSString *)strSource   appid:(NSString*)strAppId appkey:(NSString*)strAppKey;
-(void) setUnityObjectInfo:(NSString *)strObjName;
@end
