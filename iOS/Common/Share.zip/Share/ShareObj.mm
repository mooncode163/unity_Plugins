//
//  CCAdInsertObj.m
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//

#import "ShareObj.h"
#import "Common.h"
#ifdef ENABLE_SHARE
 //umeng
#import <UMShare/UMShare.h>
#endif



#define XcodeAppVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]
static NSString* const UMS_THUMB_IMAGE = @"https://mobile.umeng.com/images/pic/home/social/img-1.png";
static bool isDeviceJailbroken()
{
    bool jailbroken = NO;
    NSString *cydiaPath = @"/Applications/Cydia.app";
    NSString *aptPath = @"/private/var/lib/apt/";
    if ([[NSFileManager defaultManager] fileExistsAtPath:cydiaPath]) {
        jailbroken = YES;
    }
    
    return jailbroken;
}


@interface ShareObj()

{
//std::string strAdSource;
}
@end

@implementation ShareObj
@synthesize appId;
@synthesize appKey;
@synthesize unityObjName;

static ShareObj *s_sharedShareObj = nil;


// Init
+ (ShareObj *) sharedShareObj
{
    @synchronized(self)     {
        if (!s_sharedShareObj)
        {
            s_sharedShareObj = [[ShareObj alloc] init];
           // [s_sharedShareObj configUSharePlatforms];
        }
    }
    return s_sharedShareObj;
}


-(void) setAppId:(NSString *) strAppId
{
    
}

-(void) setUnityObjectInfo:(NSString *)strObjName
{
    self.unityObjName = strObjName;
}
- (void)initPlatform:(NSString *)strSource   appid:(NSString*)strAppId appkey:(NSString*)strAppKey
{
    #ifdef ENABLE_SHARE 
    NSLog(@"initPlatform:strSource=%@,strAppId=%@,strAppKey=%@",strSource,strAppId,strAppKey);
    UMSocialPlatformType platformType = [self getPlatform:strSource];
    if((platformType == UMSocialPlatformType_Email)||(platformType == UMSocialPlatformType_Sms))
    {
        return;
    }
     [[UMSocialManager defaultManager]  setPlaform:platformType appKey:strAppId appSecret:strAppKey redirectURL:@"http://mobile.umeng.com/social"];
    #endif

}

- (void)confitUShareSettings
{
    #ifdef ENABLE_SHARE 
    /*
     * 打开图片水印
     */
    //[UMSocialGlobal shareInstance].isUsingWaterMark = YES;
    
    /*
     * 关闭强制验证https，可允许http图片分享，但需要在info.plist设置安全域名
     <key>NSAppTransportSecurity</key>
     <dict>
     <key>NSAllowsArbitraryLoads</key>
     <true/>
     </dict>
     */
    //[UMSocialGlobal shareInstance].isUsingHttpsWhenShareContent = NO;
    #endif
}

- (void)configUSharePlatforms
{
     [self performSelectorOnMainThread:@selector(configUSharePlatformsOnMainThread) withObject:nil waitUntilDone:NO];
}
- (void)configUSharePlatformsOnMainThread
{
     #ifdef ENABLE_SHARE 
    /* 设置微信的appKey和appSecret */
    /*风云音乐台hd
     AppID：wx60e3b51b1924651c
     AppSecret f13bb1c2d33fc3db8e69ee61a42293e9
     com.mooncore.moonmusic.ipad
     月亮视频
     wx25c10c9a348a13a6
     e0f1bdfe836e811d7068c2cac34c4f6a
     com.mooncore.moonvideo
     */
    
    /*[[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wxdc1e388c3822c80b" appSecret:@"3baf1193c85774b3fd9d18447d76cab0" redirectURL:@"http://mobile.umeng.com/social"];
       [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wx60e3b51b1924651c" appSecret:@"f13bb1c2d33fc3db8e69ee61a42293e9" redirectURL:@"http://mobile.umeng.com/social"];
     */
      [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_WechatSession appKey:@"wx25c10c9a348a13a6" appSecret:@"e0f1bdfe836e811d7068c2cac34c4f6a" redirectURL:@"http://mobile.umeng.com/social"];
  
    
    /*
     * 移除相应平台的分享，如微信收藏
     */
    //[[UMSocialManager defaultManager] removePlatformProviderWithPlatformTypes:@[@(UMSocialPlatformType_WechatFavorite)]];
    
    /* 设置分享到QQ互联的appID
     * U-Share SDK为了兼容大部分平台命名，统一用appKey和appSecret进行参数设置，而QQ平台仅需将appID作为U-Share的appKey参数传进即可。
     */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_QQ appKey:@"1105821097"/*设置QQ平台的appID*/  appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
    
    /* 设置新浪的appKey和appSecret */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Sina appKey:@"3921700954"  appSecret:@"04b48b094faeb16683c32669824ebdad" redirectURL:@"https://sns.whalecloud.com/sina2/callback"];
    
    /* 钉钉的appKey */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_DingDing appKey:@"dingoalmlnohc0wggfedpk" appSecret:nil redirectURL:nil];
    
    /* 支付宝的appKey */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_AlipaySession appKey:@"2015111700822536" appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
    
    
    /* 设置易信的appKey */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_YixinSession appKey:@"yx35664bdff4db42c2b7be1e29390c1a06" appSecret:nil redirectURL:@"http://mobile.umeng.com/social"];
    
    /* 设置点点虫（原来往）的appKey和appSecret */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_LaiWangSession appKey:@"8112117817424282305" appSecret:@"9996ed5039e641658de7b83345fee6c9" redirectURL:@"http://mobile.umeng.com/social"];
    
    /* 设置领英的appKey和appSecret */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Linkedin appKey:@"81t5eiem37d2sc"  appSecret:@"7dgUXPLH8kA8WHMV" redirectURL:@"https://api.linkedin.com/v1/people"];
    
    /* 设置Twitter的appKey和appSecret */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Twitter appKey:@"fB5tvRpna1CKK97xZUslbxiet"  appSecret:@"YcbSvseLIwZ4hZg9YmgJPP5uWzd4zr6BpBKGZhf07zzh3oj62K" redirectURL:nil];
    
    /* 设置Facebook的appKey和UrlString */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Facebook appKey:@"506027402887373"  appSecret:nil redirectURL:@"http://www.umeng.com/social"];
    
    /* 设置Pinterest的appKey */
    [[UMSocialManager defaultManager] setPlaform:UMSocialPlatformType_Pinterest appKey:@"4864546872699668063"  appSecret:nil redirectURL:nil];
    
    /* dropbox的appKey */
    [[UMSocialManager defaultManager] setPlaform: UMSocialPlatformType_DropBox appKey:@"k4pn9gdwygpy4av" appSecret:@"td28zkbyb9p49xu" redirectURL:@"https://mobile.umeng.com/social"];
    
    /* vk的appkey */
    [[UMSocialManager defaultManager]  setPlaform:UMSocialPlatformType_VKontakte appKey:@"5786123" appSecret:nil redirectURL:nil];
    #endif
}



-(void) setClassePoit:(void *) p
{
    pointThis = p;
}


-(void) ShareWeb:(NSString *)strSource title:(NSString *)strTitle detail:(NSString *)strDetail url:(NSString *)strUrl
{
    #ifdef ENABLE_SHARE 
    NSLog(strSource);
     NSLog(strTitle);
     NSLog(strDetail);
//    NSLog(strPic);
     NSLog(strUrl);
    UMSocialPlatformType platformType = [self getPlatform:strSource];
    
    [self shareWebPageToPlatformType:platformType title:strTitle detail:strDetail url:strUrl];
   // [self shareTextToPlatformType:platformType];
    #endif
}

-(void) shareContentOnMainThread
{
    #ifdef ENABLE_SHARE 
    [self shareTextToPlatformType:UMSocialPlatformType_WechatSession];
     #endif
}

#ifdef ENABLE_SHARE 
-(UMSocialPlatformType) getPlatform:(NSString *)strType
{
    UMSocialPlatformType platformType = UMSocialPlatformType_WechatTimeLine;
    if([strType isEqualToString:SOURCE_WEIXIN]){
       platformType = UMSocialPlatformType_WechatSession;
    }
    if([strType isEqualToString:SOURCE_WEIXINFRIEND]){
        platformType = UMSocialPlatformType_WechatTimeLine;
    }
    if([strType isEqualToString:SOURCE_QQ]){
        platformType = UMSocialPlatformType_QQ;
    }
    if([strType isEqualToString:SOURCE_QQZONE]){
        platformType = UMSocialPlatformType_Qzone;
    }
    
    if([strType isEqualToString:SOURCE_WEIBO]){
        platformType = UMSocialPlatformType_Sina;
    }
    if([strType isEqualToString:SOURCE_EMAIL]){
        platformType = UMSocialPlatformType_Email;
    }
    if([strType isEqualToString:SOURCE_SMS]){
        platformType = UMSocialPlatformType_Sms;
    }
    return platformType;
}

   #endif

#ifdef ENABLE_SHARE 
//3.2.2  分享文本
- (void)shareTextToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    //设置文本
    messageObject.text = @"社会化组件UShare将各大社交平台接入您的应用，快速武装App。";
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }];
}
   #endif
//3.2.3  分享图片
- (void)ShareImage:(NSString *)strSource pic:(NSString *)strPic url:(NSString *)strUrl
{
    #ifdef ENABLE_SHARE 
    UMSocialPlatformType platformType = [self getPlatform:strSource];
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //创建图片内容对象
    UMShareImageObject *shareObject = [[UMShareImageObject alloc] init];
    //如果有缩略图，则设置缩略图
    shareObject.thumbImage = [UIImage imageNamed:@"AppIcon40x40"];
    UIImage *imagePic = [UIImage imageWithContentsOfFile:strPic];
    if(imagePic!=nil){
        //local image
        [shareObject setShareImage:imagePic];
    }else{
        //network image
        [shareObject setShareImage:strPic];
    }
    
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }];
     #endif
}

//3.2.4  分享图文（新浪支持，微信/QQ仅支持图或文本分享）
- (void)ShareImageText:(NSString *)strSource title:(NSString *)strTitle pic:(NSString *)strPic url:(NSString *)strUrl
{
      #ifdef ENABLE_SHARE 
     UMSocialPlatformType platformType = [self getPlatform:strSource];
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //设置文本
    messageObject.text = strTitle;
    
    //创建图片内容对象
    UMShareImageObject *shareObject = [[UMShareImageObject alloc] init];
    //如果有缩略图，则设置缩略图
    shareObject.thumbImage = [UIImage imageNamed:@"AppIcon40x40"];
    UIImage *imagePic = [UIImage imageWithContentsOfFile:strPic];
    if(imagePic!=nil){
        //local image
        [shareObject setShareImage:imagePic];
    }else{
        //network image
        [shareObject setShareImage:strPic];
    }
    
    
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }];
     #endif
}

 #ifdef ENABLE_SHARE 
//3.2.5  分享网页
- (void)shareWebPageToPlatformType:(UMSocialPlatformType)platformType title:(NSString *)strTitle detail:(NSString *)strDetail url:(NSString *)strUrl
{
       
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //创建网页内容对象
    //从Images.xcassets加载图片方法：[UIImage imageNamed:@"AppIcon40x40"]：AppIcon+图片大小参数，且文件不能带后缀
    UMShareWebpageObject *shareObject = [UMShareWebpageObject shareObjectWithTitle:strTitle descr:strDetail thumImage:[UIImage imageNamed:@"AppIcon40x40"]];//[UIImage imageNamed:@"icon"] UMS_THUMB_IMAGE
    //设置网页地址
    shareObject.webpageUrl =strUrl;//@"http://mobile.umeng.com/social";
    
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSString *str = [NSString stringWithFormat:@"************Share fail with error %@*********",error];
            NSLog(str);
            [self didFail:str];
        }else{
            NSString *str = [NSString stringWithFormat:@"response data is %@",data];
            NSLog(str);
             [self didFinish:str];
        }
    }];

       
}
 
//3.2.6  分享音乐
- (void)shareMusicToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //创建音乐内容对象
    UMShareMusicObject *shareObject = [UMShareMusicObject shareObjectWithTitle:@"分享标题" descr:@"分享内容描述" thumImage:[UIImage imageNamed:@"icon"]];
    //设置音乐网页播放地址
    shareObject.musicUrl = @"http://c.y.qq.com/v8/playsong.html?songid=108782194&source=yqq#wechat_redirect";
    //            shareObject.musicDataUrl = @"这里设置音乐数据流地址（如果有的话，而且也要看所分享的平台支不支持）";
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }]; 
}
 
//3.2.7  分享视频
- (void)shareVedioToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    //创建视频内容对象
    UMShareVideoObject *shareObject = [UMShareVideoObject shareObjectWithTitle:@"分享标题" descr:@"分享内容描述" thumImage:[UIImage imageNamed:@"icon"]];
    //设置视频网页播放地址
    shareObject.videoUrl = @"http://video.sina.com.cn/p/sports/cba/v/2013-10-22/144463050817.html";
    //            shareObject.videoStreamUrl = @"这里设置视频数据流地址（如果有的话，而且也要看所分享的平台支不支持）";
    
    //分享消息对象设置分享内容对象
    messageObject.shareObject = shareObject;
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            NSLog(@"************Share fail with error %@*********",error);
        }else{
            NSLog(@"response data is %@",data);
        }
    }];
        
}

 
//3.2.8  分享微信表情
- (void)shareEmoticonToPlatformType:(UMSocialPlatformType)platformType
{
    // UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    // UMShareEmotionObject *shareObject = [UMShareEmotionObject shareObjectWithTitle:UMS_Title descr:UMS_Text thumImage:nil];
    
    // NSString *filePath = [[NSBundle mainBundle] pathForResource:@"gifFile"
    //                                                      ofType:@"gif"];
    // NSData *emoticonData = [NSData dataWithContentsOfFile:filePath];
    // shareObject.emotionData = emoticonData;
    // messageObject.shareObject = shareObject;
    
    // //调用分享接口
    // [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
    //     if (error) {
    //         NSLog(@"************Share fail with error %@*********",error);
    //     }else{
    //         if ([data isKindOfClass:[UMSocialShareResponse class]]) {
    //             UMSocialShareResponse *resp = data;
    //             //分享结果消息
    //             NSLog(@"response message is %@",resp.message);
                
    //         }else{
    //             NSLog(@"response data is %@",data);
    //         }
    //     }
    // }];
}

//3.2.9  分享微信小程序
- (void)shareMiniProgramToPlatformType:(UMSocialPlatformType)platformType
{
    //创建分享消息对象
    UMSocialMessageObject *messageObject = [UMSocialMessageObject messageObject];
    
    UMShareMiniProgramObject *shareObject = [UMShareMiniProgramObject shareObjectWithTitle:@"小程序标题" descr:@"小程序内容描述" thumImage:[UIImage imageNamed:@"icon"]];
    shareObject.webpageUrl = @"兼容微信低版本网页地址";
    shareObject.userName = @"小程序username，如 gh_3ac2059ac66f";
    shareObject.path = @"小程序页面路径，如 pages/page10007/page10007";
    messageObject.shareObject = shareObject;
    shareObject.hdImageData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"logo" ofType:@"png"]];
    shareObject.miniProgramType = UShareWXMiniProgramTypeRelease; // 可选体验版和开发板
    
    //调用分享接口
    [[UMSocialManager defaultManager] shareToPlatform:platformType messageObject:messageObject currentViewController:[UIApplication sharedApplication].keyWindow.rootViewController completion:^(id data, NSError *error) {
        if (error) {
            UMSocialLogInfo(@"************Share fail with error %@*********",error);
        }else{
            if ([data isKindOfClass:[UMSocialShareResponse class]]) {
                UMSocialShareResponse *resp = data;
                //分享结果消息
                UMSocialLogInfo(@"response message is %@",resp.message);
                //第三方原始返回的数据
                UMSocialLogInfo(@"response originalResponse data is %@",resp.originalResponse);
                
            }else{
                UMSocialLogInfo(@"response data is %@",data);
            }
        }
        //[self alertWithError:error];
    }];
}

     #endif

#pragma mark share callback
-(void) didFail:(NSString*)str
{
    UnitySendMessage([self.unityObjName UTF8String], "ShareDidFail", [str UTF8String]);
}

-(void) didFinish:(NSString*)str
{
    UnitySendMessage([self.unityObjName UTF8String], "ShareDidFinish", [str UTF8String]);
}
 


@end

