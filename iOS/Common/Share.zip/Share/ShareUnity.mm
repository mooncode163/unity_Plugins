//
//  AdBanneriOS.mm
//
//  Created by Viraf Zack on 7/2/14
//  Copyright (c) 2014 Unity. All rights reserved.
//

#if __has_feature(objc_arc)
#define RETAIN self
#define AUTORELEASE self
#define RELEASE self
#define DEALLOC self
#else
#define RETAIN retain
#define AUTORELEASE autorelease
#define RELEASE release
#define DEALLOC dealloc
#endif

#import <Foundation/Foundation.h>
#import "ShareObj.h"

#if defined (__cplusplus)
extern "C"
{
#endif
      
    void Share_Init(const char *source,const char *appId,const char *appKey)
    {
        
         ShareObj *share = [ShareObj sharedShareObj];
        [share setAppId:[NSString stringWithUTF8String:appId]];
        
    }
    void Share_SetObjectInfo(const char*objName)
    {
        ShareObj *share = [ShareObj sharedShareObj];
        [share setUnityObjectInfo:[NSString stringWithUTF8String:objName]];
    }
    
    void Share_InitPlatform(const char *source,const char *appId,const char *appKey)
    {
        
        ShareObj *share = [ShareObj sharedShareObj];
        [share initPlatform:[NSString stringWithUTF8String:source] appid:[NSString stringWithUTF8String:appId] appkey:[NSString stringWithUTF8String:appKey]];
        
    }
    
    
    void Share_ShareWeb(const char *source,const char *title,const char *detail, const char *url)
    {
        //-(void) shareContent:(NSString *)strType title:(NSString *)strTitle detail:(NSString *)strDetail pic:(NSString *)strPic url:(NSString *)strUrl
        ShareObj *share = [ShareObj sharedShareObj];
        [share ShareWeb:[NSString stringWithUTF8String:source] title:[NSString stringWithUTF8String:title] detail:[NSString stringWithUTF8String:detail] url:[NSString stringWithUTF8String:url]];
        
    }
    void Share_ShareImage(const char *source,const char *pic, const char *url)
    {
        ShareObj *share = [ShareObj sharedShareObj];
        [share ShareImage:[NSString stringWithUTF8String:source] pic:[NSString stringWithUTF8String:pic] url:[NSString stringWithUTF8String:url]];
        
    }
    
    void Share_ShareImageText(const char *source,const char *title,const char *pic, const char *url)
    {
        ShareObj *share = [ShareObj sharedShareObj];
        [share ShareImageText:[NSString stringWithUTF8String:source] title:[NSString stringWithUTF8String:title] pic:[NSString stringWithUTF8String:pic] url:[NSString stringWithUTF8String:url]];
        
    }
    
#if defined (__cplusplus)
}
#endif

