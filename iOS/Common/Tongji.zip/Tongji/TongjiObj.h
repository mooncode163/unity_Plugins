//
//  CCAdApplistObj.h
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//

#import <Foundation/Foundation.h>


@interface TongjiObj : NSObject
{
    void *pointThis;//类指针
    
}

@property(nonatomic,retain) NSString *appId;
@property(nonatomic,retain) NSString *appKey;


+ (TongjiObj *) sharedTongjiObj;
-(void) setAppKey:(NSString *)strAppKey;
-(void) setClassePoit:(void *) p ;

@end