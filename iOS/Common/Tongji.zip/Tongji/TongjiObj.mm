//
//  CCAdInsertObj.m
//  moonma_tankcity
//
//  Created by chen Jaykie on 13-10-2.
//
//

#import "TongjiObj.h"
#import "Common.h"
#import <UMCommon/UMCommon.h>           // 公共组件是所有友盟产品的基础组件，必选
#import <UMAnalytics/MobClick.h>        // 统计组件

#define XcodeAppVersion [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]

static bool isDeviceJailbroken()
{
    bool jailbroken = NO;
    NSString *cydiaPath = @"/Applications/Cydia.app";
    NSString *aptPath = @"/private/var/lib/apt/";
    if ([[NSFileManager defaultManager] fileExistsAtPath:cydiaPath]) {
        jailbroken = YES;
    }
    
    return jailbroken;
}


@interface TongjiObj()

{
//std::string strAdSource;
}
@end

@implementation TongjiObj
@synthesize appId;
@synthesize appKey;

static TongjiObj *sharedTongjiObj = nil;


// Init
+ (TongjiObj *) sharedTongjiObj
{
    @synchronized(self)     {
        if (!sharedTongjiObj)
            sharedTongjiObj = [[TongjiObj alloc] init];
    }
    return sharedTongjiObj;
}


-(void) setAppKey:(NSString *) strAppKey
{
    
    NSString *cid;
    if (isDeviceJailbroken()) {
        cid = @"91";
    }else{
        cid = @"appstore";
    }
    
    const char *strpackage = Common_GetAppPackage();
    char *ptmp = (char *)strpackage+strlen("com.");
    char *p=strstr(ptmp, ".");
    if (p) {
        p++;
        cid = [NSString stringWithUTF8String:p];
    }
    
    // 配置友盟SDK产品并并统一初始化
    // [UMConfigure setEncryptEnabled:YES]; // optional: 设置加密传输, 默认NO.
    // [UMConfigure setLogEnabled:YES]; // 开发调试时可在console查看友盟日志显示，发布产品必须移除。
    [UMConfigure initWithAppkey:strAppKey channel:cid];
    /* appkey: 开发者在友盟后台申请的应用获得（可在统计后台的 “统计分析->设置->应用信息” 页面查看）*/
    
    // 统计组件配置
    [MobClick setScenarioType:E_UM_NORMAL];
    // [MobClick setScenarioType:E_UM_GAME];  // optional: 游戏场景设置

}




//
//-(void) show
//{
//    [self performSelectorOnMainThread:@selector(showOnMainThread) withObject:nil waitUntilDone:NO];
//}


-(void) setClassePoit:(void *) p
{
    pointThis = p;
}



#pragma mark umeng


- (void)onlineConfigCallBack:(NSNotification *)note {
    
    NSLog(@"online config has fininshed and note = %@", note.userInfo);
}

//百度移动用户统计
-(void) initBaiDuStat
{
    //    BaiduMobStat* statTracker = [BaiduMobStat defaultStat];
    //    statTracker.enableExceptionLog = YES;
    //    if (isDeviceJailbroken()) {
    //        statTracker.channelId = @"91";
    //    }
    //
    //
    //
    //    statTracker.logSendWifiOnly = YES;
    //    [statTracker startWithAppId:APPTONGJI_ID];
    
    
    
}


@end

