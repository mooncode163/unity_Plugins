//
//  AdBanneriOS.mm
//
//  Created by Viraf Zack on 7/2/14
//  Copyright (c) 2014 Unity. All rights reserved.
//
 

#import <Foundation/Foundation.h>
// #import "ShareObj.h"

#if defined (__cplusplus)
extern "C"
{
#endif
      
    void Share_Init(const char *source,const char *appId,const char *appKey)
    {
        
      
        
    }
    void Share_SetObjectInfo(const char*objName)
    {
       
    }
    
    void Share_InitPlatform(const char *source,const char *appId,const char *appKey)
    {
        
       
    }
    
    
    void Share_ShareWeb(const char *source,const char *title,const char *detail, const char *url)
    {
       
    }
    void Share_ShareImage(const char *source,const char *pic, const char *url)
    {
       
    }
    
    void Share_ShareImageText(const char *source,const char *title,const char *pic, const char *url)
    {
       
    }
    
#if defined (__cplusplus)
}
#endif

