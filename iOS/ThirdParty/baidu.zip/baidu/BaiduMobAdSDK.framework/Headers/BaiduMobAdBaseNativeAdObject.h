//
//  BaiduMobAdNativeAdObject.h
//  BaiduMobNativeSDK
//
//  Created by lishan04 on 15-5-26.
//  Copyright (c) 2015年 lishan04. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaiduMobAdCommonConfig.h"

@interface BaiduMobAdBaseNativeAdObject: NSObject
@end

